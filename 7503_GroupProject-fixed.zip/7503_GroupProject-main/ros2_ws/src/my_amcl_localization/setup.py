from setuptools import find_packages, setup
from glob import glob
import os
package_name = 'my_amcl_localization'

setup(
    name=package_name,
    version='0.0.0',
    packages=find_packages(exclude=['test']),
        data_files=[
        ('share/ament_index/resource_index/packages',
            ['resource/' + package_name]),
        ('share/' + package_name, ['package.xml']),
        # 安装launch文件
        (os.path.join('share', package_name, 'launch'), glob(os.path.join('launch', '*launch.[pxy][yma]*'))),
        # 安装config目录下的所有文件
        (os.path.join('share', package_name, 'config'), glob(os.path.join('config', '*'))),
        # 安装urdf目录下的所有文件
        (os.path.join('share', package_name, 'urdf'), glob(os.path.join('urdf', '*'))),
        # 安装map目录下的所有文件
        (os.path.join('share', package_name, 'map'), glob(os.path.join('map', '*'))),
    ],
    install_requires=['setuptools'],
    zip_safe=True,
    maintainer='scx',
    maintainer_email='scx@todo.todo',
    description='TODO: Package description',
    license='TODO: License declaration',
    extras_require={
        'test': [
            'pytest',
        ],
    },
    entry_points={
        'console_scripts': [
        ],
    },
)
