#!/usr/bin/env python3
"""Lift bridge: /lift_cmd ("up" / "down") -> servo angle on the chassis firmware.

game_manager publishes std_msgs/String 'up' / 'down' on /lift_cmd.  The firmware has
no such topic: it only listens to ``servo_s1`` and ``servo_s2`` (std_msgs/Int32,
angle in degrees, S1 -90..100, S2 -90..20, see chassis_firmware/components/servo).
This node maps the two words to angles.

The defaults come from the keyboard teleop in this repo (z = servo_s1 90, c = servo_s1 50).
WHICH ONE IS "UP" DEPENDS ON YOUR MECHANISM.  Check once with the robot on the bench:

    ros2 topic pub --once /lift_cmd std_msgs/msg/String "{data: up}"

and swap ``s1_up`` / ``s1_down`` (or set ``s2_*``) if the lift moves the wrong way.
Set an angle to -1000 to leave that servo alone.
"""

import rclpy
from rclpy.executors import ExternalShutdownException
from rclpy.node import Node
from std_msgs.msg import Int32, String

DISABLED = -1000


class LiftBridge(Node):
    def __init__(self):
        super().__init__('lift_bridge')
        self.declare_parameter('s1_up', 90)
        self.declare_parameter('s1_down', 50)
        self.declare_parameter('s2_up', DISABLED)
        self.declare_parameter('s2_down', DISABLED)
        # Re-send the angle this many times (the micro-ROS link is lossy).
        self.declare_parameter('repeat', 3)

        self._angles = {
            'up': (int(self.get_parameter('s1_up').value),
                   int(self.get_parameter('s2_up').value)),
            'down': (int(self.get_parameter('s1_down').value),
                     int(self.get_parameter('s2_down').value)),
        }
        self._repeat = max(1, int(self.get_parameter('repeat').value))
        self._pub1 = self.create_publisher(Int32, 'servo_s1', 10)
        self._pub2 = self.create_publisher(Int32, 'servo_s2', 10)
        self.create_subscription(String, '/lift_cmd', self._on_cmd, 10)
        self.get_logger().info(
            f'/lift_cmd up -> S1 {self._angles["up"][0]} deg, '
            f'down -> S1 {self._angles["down"][0]} deg')

    def _on_cmd(self, msg):
        word = msg.data.strip().lower()
        if word not in self._angles:
            self.get_logger().warning(f'unknown lift command {msg.data!r}')
            return
        s1, s2 = self._angles[word]
        self.get_logger().info(f'lift {word}: S1={s1} S2={s2}')
        for _ in range(self._repeat):
            if s1 != DISABLED:
                self._pub1.publish(Int32(data=s1))
            if s2 != DISABLED:
                self._pub2.publish(Int32(data=s2))


def main(args=None):
    rclpy.init(args=args)
    node = LiftBridge()
    try:
        rclpy.spin(node)
    except (KeyboardInterrupt, ExternalShutdownException):
        pass
    finally:
        node.destroy_node()
        if rclpy.ok():
            rclpy.shutdown()


if __name__ == '__main__':
    main()
