#!/usr/bin/env python3
"""Chassis odometry adapter: /odom_raw -> /odom + TF odom -> base_link.

What the reference micro-ROS firmware actually does (chassis_firmware/main/main.c):
  * publishes nav_msgs/Odometry on the topic  ``odom_raw``  (not ``odom``),
  * frame ids ``odom_frame`` -> ``base_footprint`` (Nav2 here uses odom -> base_link),
  * stamps from the micro-ROS agent clock, which are garbage (1970-ish) unless the
    firmware called rmw_uros_sync_session() first,
  * no TF at all.
Nav2 (AMCL, costmaps, velocity_smoother) needs /odom, the TF, and stamps that match the
Pi clock.  This node fixes all three:

  * subscribes ``odom_topic``    (default /odom_raw),
  * republishes a corrected Odometry on ``output_topic`` (default /odom),
  * broadcasts odom -> base_link,
  * stamps both with the Pi clock (+ ``tf_future_offset``, like fake_base does, so the
    lidar's "now" is never ahead of the newest transform).

    ros2 run robot_bringup odom_to_tf.py
    ros2 launch robot_bringup robot_bringup.launch.py publish_odom_tf:=true

Do not run it together with fake_base (same transform) or with firmware that already
publishes /odom and TF.  If input and output topic are equal, only TF is broadcast.
"""

import rclpy
from geometry_msgs.msg import TransformStamped
from nav_msgs.msg import Odometry
from rclpy.executors import ExternalShutdownException
from rclpy.node import Node
from tf2_ros import TransformBroadcaster


class OdomToTf(Node):
    def __init__(self):
        super().__init__('odom_to_tf')
        self.declare_parameter('odom_topic', '/odom_raw')
        self.declare_parameter('output_topic', '/odom')
        self.declare_parameter('odom_frame', 'odom')
        self.declare_parameter('base_frame', 'base_link')
        self.declare_parameter('tf_future_offset', 0.05)
        # Use the Pi clock for stamps (recommended unless the firmware has a
        # working time sync and a message-filter-safe timestamp).
        self.declare_parameter('use_pi_clock', True)

        self._in = self.get_parameter('odom_topic').value
        self._out = self.get_parameter('output_topic').value
        self._odom_frame = self.get_parameter('odom_frame').value
        self._base_frame = self.get_parameter('base_frame').value
        self._offset_ns = int(
            self.get_parameter('tf_future_offset').value * 1e9)
        self._use_pi_clock = bool(self.get_parameter('use_pi_clock').value)
        self._count = 0
        self._broadcaster = TransformBroadcaster(self)
        self._pub = None
        if self._out and self._out != self._in:
            self._pub = self.create_publisher(Odometry, self._out, 10)
        self.create_subscription(Odometry, self._in, self._on_odom, 20)
        self.create_timer(5.0, self._watchdog)
        self.get_logger().info(
            f'{self._in} -> {self._out or "(no republish)"} and TF '
            f'{self._odom_frame} -> {self._base_frame}')

    def _stamp(self, msg):
        now = self.get_clock().now()
        if self._use_pi_clock or (msg.header.stamp.sec == 0
                                  and msg.header.stamp.nanosec == 0):
            ns = now.nanoseconds + self._offset_ns
            stamp = type(msg.header.stamp)()
            stamp.sec = ns // 1_000_000_000
            stamp.nanosec = ns % 1_000_000_000
            return stamp
        return msg.header.stamp

    def _on_odom(self, msg):
        self._count += 1
        stamp = self._stamp(msg)

        transform = TransformStamped()
        transform.header.stamp = stamp
        transform.header.frame_id = self._odom_frame
        transform.child_frame_id = self._base_frame
        transform.transform.translation.x = msg.pose.pose.position.x
        transform.transform.translation.y = msg.pose.pose.position.y
        transform.transform.translation.z = msg.pose.pose.position.z
        transform.transform.rotation = msg.pose.pose.orientation
        self._broadcaster.sendTransform(transform)

        if self._pub is not None:
            out = Odometry()
            out.header.stamp = stamp
            out.header.frame_id = self._odom_frame
            out.child_frame_id = self._base_frame
            out.pose = msg.pose
            out.twist = msg.twist
            # Modest covariance if the firmware leaves it at zero, so that AMCL
            # trusts the motion model without treating it as ground truth.
            if out.pose.covariance[0] == 0.0:
                out.pose.covariance[0] = 0.02
                out.pose.covariance[7] = 0.02
                out.pose.covariance[35] = 0.05
            if out.twist.covariance[0] == 0.0:
                out.twist.covariance[0] = 0.02
                out.twist.covariance[35] = 0.05
            self._pub.publish(out)

    def _watchdog(self):
        if self._count == 0:
            self.get_logger().warning(
                f'no message on {self._in} yet - is the micro-ROS agent '
                f'running and the ESP32 connected?  (ros2 topic list | grep odom)')
        self._count = 0


def main(args=None):
    rclpy.init(args=args)
    node = OdomToTf()
    try:
        rclpy.spin(node)
    except (KeyboardInterrupt, ExternalShutdownException):
        pass
    finally:
        node.destroy_node()
        if rclpy.ok():
            rclpy.shutdown()


if __name__ == '__main__':
    main()
