#!/usr/bin/env python3
"""Mission state machine for the DASE7503 logistics game.

The whole match is driven by two inputs: QR codes from ``/qr_detected`` and
navigation results from Nav2's ``navigate_to_pose`` action.  The robot never
"sees" the field by itself except through those two channels.

State flow::

    WAIT_START --START--> DRIVE_TO_RACK --arrived--> WAIT_RACK_QR
        --RACKx_xxxx--> DOCK_RACK --under the rack--> LIFT_UP --lifted-->
        DRIVE_TO_DEST (staging pose) --arrived--> DOCK_SLOT --in the slot-->
        LIFT_DOWN --lowered--> EXIT_SLOT --backed out--> next rack ...
        ... after the last rack --> WAIT_END_QR --END--> DONE

DOCK_RACK / DOCK_SLOT / EXIT_SLOT are the "last 40 cm" the Nav2 goal tolerance
cannot do: the robot centres on the rack's QR plate (visual servoing on the
geometry published by qr_scanner on /qr_detection), then drives straight under
the rack along its normal, and later straight into / out of the drop slot.  They
talk to /cmd_vel directly and read the robot pose from TF map -> base_link.
With ``use_docking:=false`` the old behaviour (lift at the approach pose) is kept.

Run without Nav2 (dry run) to test the logic on a desk::

    ros2 run game_manager game_manager --ros-args -p use_nav2:=false

In dry-run mode every "drive" simply takes ``dry_run_travel_time`` seconds,
so QR events can be injected by hand::

    ros2 topic pub --once /qr_detected std_msgs/msg/String \
        "{data: 'START'}"
"""

import json
import math

import rclpy
from action_msgs.msg import GoalStatus
from geometry_msgs.msg import PoseStamped, PoseWithCovarianceStamped, Twist
from rclpy.action import ActionClient
from rclpy.clock import ClockType
from rclpy.duration import Duration
from rclpy.executors import ExternalShutdownException
from rclpy.node import Node
from rclpy.time import Time
from std_msgs.msg import Bool, Int32, String

from .motion import (Pose2D, line_cmd, plate_in_map, rack_centre_from_plate,
                     servo_cmd, wrap)

try:
    from nav2_msgs.action import NavigateToPose
except ImportError:  # allows dry-run testing on machines without Nav2
    NavigateToPose = None

try:
    from tf2_ros import Buffer, TransformListener
except ImportError:  # dry-run on a machine without tf2
    Buffer = TransformListener = None

WAIT_START = 'WAIT_START'
DRIVE_TO_RACK = 'DRIVE_TO_RACK'
WAIT_RACK_QR = 'WAIT_RACK_QR'
DOCK_RACK = 'DOCK_RACK'
LIFT_UP = 'LIFT_UP'
DRIVE_TO_DEST = 'DRIVE_TO_DEST'
DOCK_SLOT = 'DOCK_SLOT'
LIFT_DOWN = 'LIFT_DOWN'
EXIT_SLOT = 'EXIT_SLOT'
WAIT_END_QR = 'WAIT_END_QR'
DONE = 'DONE'

RACK_LETTERS = ('A', 'B', 'C', 'D')
POINTS_PER_SHIPMENT = 5


def yaw_to_quaternion(yaw):
    """Return the (x, y, z, w) quaternion for a rotation about z."""
    return 0.0, 0.0, math.sin(yaw / 2.0), math.cos(yaw / 2.0)


class GameManager(Node):
    """Runs one match: START QR -> 4 racks -> destination -> END QR."""

    def __init__(self):
        super().__init__('game_manager')

        self.declare_parameter('use_nav2', True)
        self.declare_parameter('set_initial_pose', False)
        self.declare_parameter('dry_run_travel_time', 3.0)
        self.declare_parameter('mission_timeout', 180.0)
        self.declare_parameter('rack_scan_timeout', 15.0)
        self.declare_parameter('end_scan_timeout', 20.0)
        self.declare_parameter('lift_time', 1.5)
        self.declare_parameter('rack_order', 'A,B,C,D')
        self.declare_parameter('require_end_qr', True)

        # The END plate sits at the destination point, so the camera sees it
        # on every delivery.  Treating a mid-mission END as "stop" would end
        # the match after the first rack, so it is ignored unless asked for.
        self.declare_parameter('end_qr_stops_mission', False)
        # Only accept the QR of the rack we drove to.  A plate from the
        # neighbouring rack can enter the frame at the approach pose.
        self.declare_parameter('strict_rack_match', True)
        # A rack QR first seen on the way in stays valid this long, so the
        # robot does not have to re-read a plate it is already parked under.
        self.declare_parameter('rack_qr_cache_time', 30.0)

        self.declare_parameter('start_x', 2.6)
        self.declare_parameter('start_y', 0.4)
        self.declare_parameter('start_yaw', 0.0)
        self.declare_parameter('destination_x', 0.15)
        self.declare_parameter('destination_y', 1.0)
        self.declare_parameter('destination_yaw', 3.1416)
        for letter in RACK_LETTERS:
            key = letter.lower()
            self.declare_parameter(f'rack_{key}_x', 0.8)
            self.declare_parameter(f'rack_{key}_y', 1.6)
            self.declare_parameter(f'rack_{key}_yaw', 0.0)

        # Optional per-delivery drop points inside the destination zone,
        # "x,y,yaw;x,y,yaw;...".  Each delivery uses the next one, so the
        # robot does not drive into the rack it dropped last time.
        self.declare_parameter('destination_points', '')

        # ---- docking: the last 40 cm into / out of a rack or a drop slot ----
        self.declare_parameter('use_docking', True)
        self.declare_parameter('rack_front_yaw', 0.0)      # QR face direction
        self.declare_parameter('plate_to_center', 0.074)   # QR plate -> rack centre
        self.declare_parameter('camera_forward', 0.12)     # camera x on base_link
        self.declare_parameter('stop_range', 0.30)         # servo stop distance
        self.declare_parameter('lift_offset', 0.0)         # lift centre ahead of base_link
        self.declare_parameter('stage_distance', 0.35)
        self.declare_parameter('dock_timeout', 25.0)
        self.declare_parameter('servo_acquire_timeout', 2.5)
        self.declare_parameter('v_servo', 0.08)
        self.declare_parameter('v_line', 0.10)
        self.declare_parameter('v_exit', 0.12)
        self.declare_parameter('dry_run_dock_time', 1.5)
        # While waiting for END, turn in place to look for the plate.
        self.declare_parameter('end_scan_spin_w', 0.5)
        # At the approach pose the rack's plate may sit just outside the camera's
        # field of view (Nav2 stops within 10 cm / 11 deg of the goal, the rack
        # position is only known to a few cm): after `delay` s without the QR,
        # sweep left / right by about +-0.5 rad until it shows up.
        self.declare_parameter('rack_scan_sweep_w', 0.35)
        self.declare_parameter('rack_scan_sweep_delay', 2.0)
        self.declare_parameter('rack_scan_sweep_period', 1.5)
        for letter in RACK_LETTERS:
            key = letter.lower()
            self.declare_parameter(f'rack_{key}_cx', 0.0)  # nominal centre
            self.declare_parameter(f'rack_{key}_cy', 0.0)

        self._use_nav2 = bool(self.get_parameter('use_nav2').value)
        self._set_initial_pose = bool(
            self.get_parameter('set_initial_pose').value)
        self._dry_run_time = float(
            self.get_parameter('dry_run_travel_time').value)
        self._mission_timeout = float(
            self.get_parameter('mission_timeout').value)
        self._rack_scan_timeout = float(
            self.get_parameter('rack_scan_timeout').value)
        self._end_scan_timeout = float(
            self.get_parameter('end_scan_timeout').value)
        self._lift_time = float(self.get_parameter('lift_time').value)
        self._require_end_qr = bool(
            self.get_parameter('require_end_qr').value)
        self._end_qr_stops_mission = bool(
            self.get_parameter('end_qr_stops_mission').value)
        self._strict_rack_match = bool(
            self.get_parameter('strict_rack_match').value)
        self._rack_qr_cache_time = float(
            self.get_parameter('rack_qr_cache_time').value)
        self._destination_points = self._parse_destination_points(
            str(self.get_parameter('destination_points').value))
        self._use_docking = bool(self.get_parameter('use_docking').value)
        self._front_yaw = self._param('rack_front_yaw')
        self._plate_to_center = self._param('plate_to_center')
        self._camera_forward = self._param('camera_forward')
        self._stop_range = self._param('stop_range')
        self._lift_offset = self._param('lift_offset')
        self._stage_distance = self._param('stage_distance')
        self._dock_timeout = self._param('dock_timeout')
        self._servo_acquire_timeout = self._param('servo_acquire_timeout')
        self._v_servo = self._param('v_servo')
        self._v_line = self._param('v_line')
        self._v_exit = self._param('v_exit')
        self._dry_run_dock_time = self._param('dry_run_dock_time')
        self._end_spin_w = self._param('end_scan_spin_w')
        self._sweep_w = self._param('rack_scan_sweep_w')
        self._sweep_delay = self._param('rack_scan_sweep_delay')
        self._sweep_period = self._param('rack_scan_sweep_period')
        self._state_t0 = 0.0

        order = str(self.get_parameter('rack_order').value)
        self._rack_order = [letter.strip().upper()
                            for letter in order.split(',')
                            if letter.strip().upper() in RACK_LETTERS]

        self._state = WAIT_START
        self._state_pub = self.create_publisher(String, '/game_state', 10)
        self._score_pub = self.create_publisher(Int32, '/game_score', 10)
        self._lift_pub = self.create_publisher(String, '/lift_cmd', 10)
        self._initial_pose_pub = self.create_publisher(
            PoseWithCovarianceStamped, '/initialpose', 10)

        self._cmd_pub = self.create_publisher(Twist, '/cmd_vel', 10)
        self._qr_fast_pub = self.create_publisher(Bool, '/qr_fast_mode', 10)

        self.create_subscription(
            String, '/qr_detected', self._on_qr, 10)
        # Geometry of every decoded QR (JSON: text, fwd, left, bearing, stamp).
        self.create_subscription(
            String, '/qr_detection', self._on_qr_detection, 10)
        self._detections = {}     # text -> latest detection dict
        self._geometry_seen = False   # has qr_scanner ever published /qr_detection?
        self._tf_buffer = None
        if self._use_nav2 and Buffer is not None:
            self._tf_buffer = Buffer()
            self._tf_listener = TransformListener(self._tf_buffer, self)

        self._nav_client = None
        if self._use_nav2:
            if NavigateToPose is None:
                self.get_logger().error(
                    'nav2_msgs is not installed; falling back to dry run')
                self._use_nav2 = False
            else:
                self._nav_client = ActionClient(
                    self, NavigateToPose, 'navigate_to_pose')

        self._mailbox = []       # pending QR payloads, drained in _tick
        self._mission_start = None
        self._deadline = None
        self._arrive_at = None
        self._queue = []
        self._current_rack = None
        self._delivered = []
        self._goal_handle = None
        self._dest_attempts = 0
        self._rack_attempts = 0
        self._rack_qr_cache = {}  # letter -> (payload, clock ns)
        self._dock = None         # active docking motion (dict) or None
        self._delivery_counts = True
        self._fast_ticks = 0

        self._set_state(WAIT_START)
        self._publish_score()
        self.create_timer(0.1, self._on_tick)
        self.create_timer(0.05, self._on_motion_tick)

        mode = 'Nav2' if self._use_nav2 else 'DRY RUN (no Nav2)'
        self.get_logger().info(f'game_manager ready in {mode} mode; '
                               f'waiting for START QR')

    # ------------------------------------------------------------------ QR

    def _on_qr(self, msg):
        # Decode happens in another node; queue here so the state machine
        # changes in one place (the timer) instead of inside a callback.
        self._mailbox.append(msg.data.strip())
        if len(self._mailbox) > 20:
            del self._mailbox[:-20]

    def _on_qr_detection(self, msg):
        try:
            det = json.loads(msg.data)
        except ValueError:
            return
        det['rx_ns'] = self.get_clock().now().nanoseconds
        self._geometry_seen = True
        self._detections[det.get('text', '')] = det

    def _latest_detection(self, prefix, max_age=0.5):
        now = self.get_clock().now().nanoseconds
        best = None
        for text, det in self._detections.items():
            if text.startswith(prefix) and (now - det['rx_ns']) / 1e9 <= max_age:
                if best is None or det['rx_ns'] > best['rx_ns']:
                    best = det
        return best

    def _drain_mailbox(self):
        while self._mailbox:
            text = self._mailbox.pop(0)
            self._handle_qr(text)

    def _handle_qr(self, text):
        if not text:
            return
        if text == 'START':
            if self._state == WAIT_START:
                self._begin_mission()
            else:
                self.get_logger().info('START QR ignored (mission already on)')
        elif text == 'END':
            if self._state == WAIT_END_QR:
                self._finish('END QR scanned')
            elif self._state == DONE:
                pass
            elif self._state == WAIT_START:
                self.get_logger().info('END QR ignored (mission not started)')
            elif self._end_qr_stops_mission:
                # Opt-in emergency stop; never on for the real field.
                self.get_logger().warning('END QR seen mid-mission, finishing')
                self._finish('END QR scanned early')
            else:
                # The END plate is at the destination, so it is in view on
                # every delivery.  It must not end the match early.
                self.get_logger().info(
                    f'END QR seen while {self._state}, ignored')
        elif text.startswith('RACK'):
            self._handle_rack_qr(text)
        else:
            self.get_logger().warn(f'unknown QR payload: {text!r}')

    def _handle_rack_qr(self, text):
        # RACKA_4X6M -> letter 'A'
        letter = text[4:5].upper() if len(text) > 4 else ''
        if letter not in RACK_LETTERS:
            self.get_logger().warn(f'not a rack QR: {text!r}')
            return

        # Keep every rack tag we see.  The camera usually reads the plate
        # while the robot is still driving towards the rack, before the
        # state machine is waiting for it; the cached copy is reused on
        # arrival so a plate that is now out of view is not lost.
        self._rack_qr_cache[letter] = (
            text, self.get_clock().now().nanoseconds)

        if self._state != WAIT_RACK_QR:
            self.get_logger().debug(f'{text} seen while {self._state}, cached')
            return
        if self._current_rack and letter != self._current_rack:
            if self._strict_rack_match:
                self.get_logger().warning(
                    f'at rack {self._current_rack} but scanned {letter}; '
                    f'ignoring it')
                return
            self.get_logger().warn(
                f'expected rack {self._current_rack} but scanned '
                f'{letter}; using the scanned one for delivery record')
            self._current_rack = letter
        self.get_logger().info(f'rack QR confirmed: {text}')
        if self._use_docking:
            self._start_dock_rack()
        else:
            self._lift_up()

    # --------------------------------------------------------------- states

    def _set_state(self, state):
        self._state = state
        self._state_t0 = self.get_clock().now().nanoseconds / 1e9
        self._state_pub.publish(String(data=state))
        self.get_logger().info(f'state -> {state}')

    def _begin_mission(self):
        self._mission_start = self.get_clock().now()
        self._delivered = []
        self._queue = list(self._rack_order)
        self._dest_attempts = 0
        self._rack_qr_cache.clear()
        self._publish_score()
        self.get_logger().info(
            f'START scanned; {len(self._queue)} racks queued: '
            f'{", ".join(self._queue)}')
        if self._set_initial_pose:
            self._publish_initial_pose()
        self._next_rack()

    def _next_rack(self):
        if self._mission_timed_out():
            self._finish('mission timeout')
            return
        if not self._queue:
            if self._require_end_qr:
                self._set_state(WAIT_END_QR)
                self._deadline = self._now_plus(self._end_scan_timeout)
                self.get_logger().info(
                    'all racks delivered; waiting for END QR')
            else:
                self._finish('all racks delivered')
            return
        self._cmd(0.0, 0.0)
        self._current_rack = self._queue.pop(0)
        self._rack_attempts = 0
        self._dock = None
        self._delivery_counts = True
        self._qr_fast(True)          # read the plate early, at the faster decode rate
        self._set_state(DRIVE_TO_RACK)
        key = self._current_rack.lower()
        self._drive_to(
            self._param(f'rack_{key}_x'),
            self._param(f'rack_{key}_y'),
            self._param(f'rack_{key}_yaw'),
        )

    def _lift_up(self):
        self._dock = None
        self._qr_fast(False)
        self._set_state(LIFT_UP)
        self._lift_pub.publish(String(data='up'))
        self._deadline = self._now_plus(self._lift_time)
        self.get_logger().info(
            f'lift up for rack {self._current_rack}')

    def _drive_to_destination(self):
        self._set_state(DRIVE_TO_DEST)
        if self._use_docking:
            self._drive_to(*self._staging_pose())
        else:
            self._drive_to(*self._destination_pose())

    def _lift_down(self):
        self._set_state(LIFT_DOWN)
        self._lift_pub.publish(String(data='down'))
        self._deadline = self._now_plus(self._lift_time)

    def _delivery_done(self):
        self._dock = None
        if (self._delivery_counts and self._current_rack
                and self._current_rack not in self._delivered):
            self._delivered.append(self._current_rack)
            self.get_logger().info(
                f'shipment delivered ({len(self._delivered)} total, '
                f'score {len(self._delivered) * POINTS_PER_SHIPMENT})')
        elif not self._delivery_counts:
            self.get_logger().warn(
                f'rack {self._current_rack} was NOT delivered; moving on')
        self._publish_score()
        self._current_rack = None
        self._dest_attempts = 0
        self._next_rack()

    def _finish(self, reason):
        if self._state == DONE:
            return
        self._dock = None
        self._cmd(0.0, 0.0)
        self._qr_fast(False)
        if self._goal_handle is not None:
            self._goal_handle.cancel_goal_async()
            self._goal_handle = None
        self._lift_pub.publish(String(data='down'))
        self._set_state(DONE)
        self.get_logger().info(
            f'mission finished: {reason}; '
            f'{len(self._delivered)} shipments, '
            f'score {len(self._delivered) * POINTS_PER_SHIPMENT}')

    # -------------------------------------------------------------- driving

    def _drive_to(self, x, y, yaw):
        if self._state == DRIVE_TO_RACK:
            self._dest_attempts = 0
        self.get_logger().info(
            f'driving to ({x:.2f}, {y:.2f}, {yaw:.2f})')
        if not self._use_nav2:
            self._arrive_at = self._now_plus(self._dry_run_time)
            return
        if not self._nav_client.wait_for_server(timeout_sec=5.0):
            self.get_logger().error(
                'navigate_to_pose server not available; aborting drive')
            self._on_arrival_failed()
            return
        goal = NavigateToPose.Goal()
        goal.pose = self._pose(x, y, yaw)
        self._nav_client.send_goal_async(goal).add_done_callback(
            self._on_goal_response)

    def _pose(self, x, y, yaw):
        msg = PoseStamped()
        msg.header.frame_id = 'map'
        msg.header.stamp = self.get_clock().now().to_msg()
        msg.pose.position.x = float(x)
        msg.pose.position.y = float(y)
        msg.pose.position.z = 0.0
        qx, qy, qz, qw = yaw_to_quaternion(yaw)
        msg.pose.orientation.x = qx
        msg.pose.orientation.y = qy
        msg.pose.orientation.z = qz
        msg.pose.orientation.w = qw
        return msg

    def _publish_initial_pose(self):
        msg = PoseWithCovarianceStamped()
        msg.header.frame_id = 'map'
        msg.header.stamp = self.get_clock().now().to_msg()
        msg.pose.pose = self._pose(
            self._param('start_x'),
            self._param('start_y'),
            self._param('start_yaw')).pose
        for i in range(6):
            msg.pose.covariance[i * 7] = 0.25 if i < 3 else 0.07
        self._initial_pose_pub.publish(msg)
        self.get_logger().info('initial pose published')

    def _on_goal_response(self, future):
        goal_handle = future.result()
        if not goal_handle.accepted:
            self.get_logger().error('navigation goal rejected')
            self._on_arrival_failed()
            return
        self._goal_handle = goal_handle
        goal_handle.get_result_async().add_done_callback(self._on_goal_result)

    def _on_goal_result(self, future):
        self._goal_handle = None
        status = future.result().status
        if status == GoalStatus.STATUS_SUCCEEDED:
            self._on_arrival()
        else:
            self.get_logger().warn(f'navigation failed (status={status})')
            self._on_arrival_failed()

    def _on_arrival(self):
        if self._state == DRIVE_TO_RACK:
            self._set_state(WAIT_RACK_QR)
            self._deadline = self._now_plus(self._rack_scan_timeout)
            self.get_logger().info(
                f'at rack {self._current_rack}; waiting for its QR')
            cached = self._recent_rack_qr(self._current_rack)
            if cached is not None:
                self.get_logger().info(
                    f'rack QR read on approach: {cached}')
                self._handle_rack_qr(cached)
        elif self._state == DRIVE_TO_DEST:
            if self._use_docking:
                self._start_dock_slot()
            else:
                self._lift_down()
        else:
            self.get_logger().warn(f'arrival in unexpected state {self._state}')

    def _on_arrival_failed(self):
        if self._state == DRIVE_TO_RACK:
            self._rack_attempts += 1
            if self._rack_attempts < 2:
                # A single action-server timeout on a loaded Pi must not
                # cost a whole rack; try the same goal once more.
                self.get_logger().warn(
                    f'cannot reach rack {self._current_rack}; retrying once')
                key = self._current_rack.lower()
                self._drive_to(
                    self._param(f'rack_{key}_x'),
                    self._param(f'rack_{key}_y'),
                    self._param(f'rack_{key}_yaw'))
            else:
                self.get_logger().warn(
                    f'giving up on rack {self._current_rack}')
                self._next_rack()
        elif self._state == DRIVE_TO_DEST:
            self._dest_attempts += 1
            if self._dest_attempts < 2:
                self.get_logger().warn('retrying destination once')
                self._drive_to(*self._destination_pose())
            else:
                # Do not throw away the rest of the match: put the rack down
                # here (it will not count) and go on with the next one.
                self.get_logger().warn(
                    'cannot reach the drop slot; lowering the rack here')
                self._delivery_counts = False
                self._lift_down()

    # ---------------------------------------------------------------- timer

    def _on_tick(self):
        self._drain_mailbox()
        if self._state == DONE:
            return
        now = self.get_clock().now()

        if self._state == WAIT_START:
            return
        if self._mission_timed_out():
            self._finish('mission timeout')
            return

        self._fast_ticks += 1
        if self._fast_ticks % 10 == 0 and self._state in (
                DRIVE_TO_RACK, WAIT_RACK_QR, DOCK_RACK):
            self._qr_fast(True)      # keep the QR scanner in fast mode (1 Hz refresh)

        if self._state in (DRIVE_TO_RACK, DRIVE_TO_DEST):
            if self._arrive_at is not None and now >= self._arrive_at:
                self._arrive_at = None
                self._on_arrival()
        elif self._state in (DOCK_RACK, DOCK_SLOT, EXIT_SLOT):
            # Dry run / no TF: nothing moves, the dock simply takes a moment.
            if (self._dock is None and self._arrive_at is not None
                    and now >= self._arrive_at):
                self._arrive_at = None
                self._dock_finished(ok=True)
        elif self._state == WAIT_RACK_QR:
            if now >= self._deadline:
                self.get_logger().warn(
                    f'no rack QR within {self._rack_scan_timeout:.0f} s; '
                    f'skipping rack {self._current_rack}')
                self._next_rack()
        elif self._state in (LIFT_UP, LIFT_DOWN):
            if now >= self._deadline:
                if self._state == LIFT_UP:
                    self._drive_to_destination()
                elif self._use_docking and self._delivery_counts:
                    self._start_exit_slot()
                else:
                    self._delivery_done()
        elif self._state == WAIT_END_QR:
            if now >= self._deadline:
                self._finish('END QR not seen in time')


    # -------------------------------------------------------------- docking

    def _cmd(self, v, w):
        msg = Twist()
        msg.linear.x = float(v)
        msg.angular.z = float(w)
        self._cmd_pub.publish(msg)

    def _qr_fast(self, on):
        self._qr_fast_pub.publish(Bool(data=bool(on)))

    def _get_pose(self, stamp=None):
        """Robot pose in the map frame (None until TF is available)."""
        if self._tf_buffer is None:
            return None
        try:
            if stamp is None:
                when = Time()
            else:
                when = Time(seconds=int(stamp[0]), nanoseconds=int(stamp[1]),
                            clock_type=ClockType.ROS_TIME)
            tf = self._tf_buffer.lookup_transform('map', 'base_link', when)
        except Exception:  # noqa: BLE001 - extrapolation etc.
            if stamp is not None:
                return self._get_pose(None)
            return None
        q = tf.transform.rotation
        yaw = math.atan2(2.0 * (q.w * q.z + q.x * q.y),
                         1.0 - 2.0 * (q.y * q.y + q.z * q.z))
        return Pose2D(tf.transform.translation.x, tf.transform.translation.y,
                      yaw)

    def _secs(self):
        return self.get_clock().now().nanoseconds / 1e9

    def _begin_dock(self, kind):
        self._deadline = self._now_plus(self._dock_timeout)
        self._arrive_at = None
        if not self._use_nav2 or self._tf_buffer is None:
            self._dock = None
            self._arrive_at = self._now_plus(self._dry_run_dock_time)
            return False
        self._dock = {'kind': kind, 't0': self._secs(), 'no_pose_since': None}
        return True

    def _start_dock_rack(self):
        letter = self._current_rack
        self._set_state(DOCK_RACK)
        if not self._begin_dock('rack'):
            return
        key = letter.lower()
        self._dock.update({
            'phase': 'servo', 'letter': letter, 'plates': [], 'last_det_ns': 0,
            'seen': False, 'last_seen': self._secs(),
            'centre': (self._param(f'rack_{key}_cx'),
                       self._param(f'rack_{key}_cy')),
            'source': 'nominal',
        })
        self.get_logger().info(
            f'docking with rack {letter}: centring on its QR plate')

    def _start_dock_slot(self):
        x, y, yaw = self._destination_pose()
        self._set_state(DOCK_SLOT)
        if not self._begin_dock('slot'):
            return
        # hook centre (lift_offset ahead of base_link) must end on the slot centre
        self._dock.update({'centre': (x, y), 'heading': yaw,
                           's_goal': -self._lift_offset, 'speed': self._v_line})
        self.get_logger().info(f'driving into the slot at ({x:.2f}, {y:.2f})')

    def _start_exit_slot(self):
        x, y, yaw = self._destination_pose()
        self._set_state(EXIT_SLOT)
        if not self._begin_dock('exit'):
            return
        self._dock.update({'centre': (x, y), 'heading': yaw,
                           's_goal': -self._stage_distance,
                           'speed': self._v_exit})

    def _dock_finished(self, ok):
        """A docking motion ended (or timed out): move the mission on."""
        self._cmd(0.0, 0.0)
        state = self._state
        self._dock = None
        if state == DOCK_RACK:
            if ok:
                self._lift_up()
            else:
                self._qr_fast(False)
                self.get_logger().warn(
                    f'docking with rack {self._current_rack} failed; skipping it')
                self._next_rack()
        elif state == DOCK_SLOT:
            if not ok:
                self.get_logger().warn('slot docking timed out; lowering here')
            self._lift_down()
        elif state == EXIT_SLOT:
            if not ok:
                self.get_logger().warn('backing out of the slot timed out')
            self._delivery_done()

    def _on_motion_tick(self):
        if (self._state == WAIT_END_QR and self._use_nav2
                and self._end_spin_w != 0.0):
            self._cmd(0.0, self._end_spin_w)     # sweep the camera over the field
            return
        if (self._state == WAIT_RACK_QR and self._use_nav2 and self._use_docking
                and self._sweep_w != 0.0):
            waited = self._secs() - self._state_t0 - self._sweep_delay
            if waited > 0.0:
                # left, right, right, left: visits +0.5, 0, -0.5, 0 rad
                phase = int(waited / self._sweep_period) % 4
                self._cmd(0.0, self._sweep_w * (1.0, -1.0, -1.0, 1.0)[phase])
            return
        dock = self._dock
        if dock is None or self._state not in (DOCK_RACK, DOCK_SLOT, EXIT_SLOT):
            return
        if self.get_clock().now() >= self._deadline:
            self._dock_finished(ok=False)
            return
        pose = self._get_pose()
        if pose is None:
            self._cmd(0.0, 0.0)
            if dock['no_pose_since'] is None:
                dock['no_pose_since'] = self._secs()
            elif self._secs() - dock['no_pose_since'] > 2.0:
                self.get_logger().error('no map -> base_link TF; docking aborted')
                self._dock_finished(ok=False)
            return
        dock['no_pose_since'] = None

        if dock['kind'] == 'rack':
            self._tick_dock_rack(dock, pose)
        else:
            v, w, done = line_cmd(
                pose, dock['centre'], dock['heading'], dock['s_goal'],
                v_max=dock['speed'])
            if done:
                self._dock_finished(ok=True)
            else:
                self._cmd(v, w)

    def _tick_dock_rack(self, dock, pose):
        prefix = f'RACK{dock["letter"]}_'
        heading = wrap(self._front_yaw + math.pi)   # drive INTO the rack
        now = self._secs()

        if dock['phase'] == 'enter':
            v, w, done = line_cmd(pose, dock['centre'], heading,
                                  -self._lift_offset, v_max=self._v_line)
            if done:
                self.get_logger().info(
                    f'under rack {dock["letter"]} (centre from {dock["source"]})')
                self._dock_finished(ok=True)
            else:
                self._cmd(v, w)
            return

        # ---- servo phase: keep the QR plate centred until it is stop_range ahead
        det = self._latest_detection(prefix)
        if det is not None and det['rx_ns'] != dock['last_det_ns']:
            dock['last_det_ns'] = det['rx_ns']
            dock['seen'] = True
            dock['last_seen'] = now
            det_pose = self._get_pose((det.get('sec', 0), det.get('nanosec', 0))) or pose
            if det['fwd'] < 0.8:
                dock['plates'].append(plate_in_map(
                    det_pose, self._camera_forward, det['fwd'], det['left']))
                del dock['plates'][:-8]

        plates = dock['plates']
        if len(plates) >= 3:
            # Control on the median plate position seen from the CURRENT pose:
            # no latency, and it keeps working when the plate leaves the image.
            xs = sorted(p[0] for p in plates)
            ys = sorted(p[1] for p in plates)
            est = (xs[len(xs) // 2], ys[len(ys) // 2])
            cam_x = pose.x + self._camera_forward * math.cos(pose.yaw)
            cam_y = pose.y + self._camera_forward * math.sin(pose.yaw)
            dx, dy = est[0] - cam_x, est[1] - cam_y
            fwd = dx * math.cos(pose.yaw) + dy * math.sin(pose.yaw)
            left = -dx * math.sin(pose.yaw) + dy * math.cos(pose.yaw)
            v, w, done = servo_cmd(math.atan2(left, fwd), fwd,
                                   self._stop_range, v_max=self._v_servo)
            if done:
                dock['centre'] = rack_centre_from_plate(
                    est, self._plate_to_center, self._front_yaw)
                dock['source'] = 'QR'
                dock['phase'] = 'enter'
                self._cmd(0.0, 0.0)
                self.get_logger().info(
                    f'plate centred; rack centre ({dock["centre"][0]:.3f}, '
                    f'{dock["centre"][1]:.3f}) from the QR')
            else:
                self._cmd(v, w)
            return

        # not enough QR geometry yet
        self._cmd(0.0, 0.0)
        waited = now - (dock['last_seen'] if dock['seen'] else dock['t0'])
        if waited > self._servo_acquire_timeout:
            if self._geometry_seen:
                # The scanner works, but THIS rack's plate is not in view: the robot
                # is probably not at that rack (stale QR cache, wrong coordinates).
                # Driving blindly under whatever stands there would be worse than
                # skipping the rack.
                self.get_logger().warn(
                    f'rack {dock["letter"]}: its QR plate is not in view although '
                    f'the scanner works; giving up on this rack')
                self._dock_finished(ok=False)
                return
            self.get_logger().warn(
                'no QR geometry on /qr_detection; docking on the nominal rack centre')
            dock['phase'] = 'enter'
            dock['source'] = 'nominal'

    # -------------------------------------------------------------- helpers

    def _mission_timed_out(self):
        if self._mission_start is None:
            return False
        elapsed = (self.get_clock().now() - self._mission_start).nanoseconds
        return elapsed >= self._mission_timeout * 1e9

    def _now_plus(self, seconds):
        return self.get_clock().now() + Duration(seconds=seconds)

    def _destination_pose(self):
        """Return (x, y, yaw) for the current delivery."""
        if self._destination_points:
            index = len(self._delivered) % len(self._destination_points)
            return self._destination_points[index]
        return (self._param('destination_x'),
                self._param('destination_y'),
                self._param('destination_yaw'))

    def _staging_pose(self):
        """Pose `stage_distance` m behind the drop pose (in front of the slot)."""
        x, y, yaw = self._destination_pose()
        return (x - self._stage_distance * math.cos(yaw),
                y - self._stage_distance * math.sin(yaw), yaw)

    def _recent_rack_qr(self, letter):
        entry = self._rack_qr_cache.get(letter)
        if entry is None:
            return None
        payload, stamp_ns = entry
        age = (self.get_clock().now().nanoseconds - stamp_ns) / 1e9
        if age > self._rack_qr_cache_time:
            return None
        return payload

    def _parse_destination_points(self, spec):
        points = []
        for chunk in spec.split(';'):
            chunk = chunk.strip()
            if not chunk:
                continue
            values = [value.strip() for value in chunk.split(',')]
            if len(values) != 3:
                self.get_logger().error(
                    f'bad destination point {chunk!r}, expected "x,y,yaw"')
                continue
            try:
                points.append(tuple(float(value) for value in values))
            except ValueError:
                self.get_logger().error(
                    f'bad destination point {chunk!r}, expected "x,y,yaw"')
        return points

    def _param(self, name):
        return float(self.get_parameter(name).value)

    def _publish_score(self):
        self._score_pub.publish(
            Int32(data=len(self._delivered) * POINTS_PER_SHIPMENT))


def main(args=None):
    rclpy.init(args=args)
    node = GameManager()
    try:
        rclpy.spin(node)
    except (KeyboardInterrupt, ExternalShutdownException):
        pass
    finally:
        node.destroy_node()
        if rclpy.ok():
            rclpy.shutdown()


if __name__ == '__main__':
    main()
