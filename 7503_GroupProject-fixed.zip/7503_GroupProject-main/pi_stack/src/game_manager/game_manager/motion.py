"""Pure motion helpers for docking with a rack (no ROS imports, easy to test).

Conventions: map frame, x forward / y left / yaw counter-clockwise, metres and radians.
Every controller returns ``(v, w, done)`` -- linear and angular velocity for base_link.
"""
import math
from dataclasses import dataclass


def wrap(angle):
    """Wrap an angle to (-pi, pi]."""
    return math.atan2(math.sin(angle), math.cos(angle))


def clamp(value, low, high):
    return max(low, min(high, value))


@dataclass
class Pose2D:
    x: float
    y: float
    yaw: float


def robot_to_map(pose, fx, fy):
    """Point in the robot frame (x forward, y left) -> map frame."""
    c, s = math.cos(pose.yaw), math.sin(pose.yaw)
    return pose.x + c * fx - s * fy, pose.y + s * fx + c * fy


def plate_in_map(pose, camera_forward, fwd, left):
    """Map position of a QR plate seen `fwd` m ahead / `left` m to the left of the camera."""
    return robot_to_map(pose, camera_forward + fwd, left)


def rack_centre_from_plate(plate_xy, plate_to_center, front_yaw):
    """The QR plate sits on the rack's front face; the centre is behind it."""
    return (plate_xy[0] - plate_to_center * math.cos(front_yaw),
            plate_xy[1] - plate_to_center * math.sin(front_yaw))


def servo_cmd(bearing, fwd, stop_fwd, v_max=0.08, k_ang=2.0, w_max=0.6):
    """Visual servoing on a QR plate.

    bearing: angle to the plate, left positive [rad]; fwd: horizontal camera->plate distance [m].
    Steers to keep the plate centred, slows down when it is off-centre and near the stop range.
    """
    if fwd <= stop_fwd:
        return 0.0, 0.0, True
    w = clamp(k_ang * bearing, -w_max, w_max)
    centred = max(0.0, 1.0 - abs(bearing) / 0.45)
    v = min(v_max, 0.5 * (fwd - stop_fwd) + 0.03) * centred
    return v, w, False


def line_cmd(pose, c_xy, heading, s_goal, v_max=0.10, k_e=12.0, k_h=3.5, tol=0.01, w_max=0.8):
    """Follow the straight line through c_xy with direction `heading`.

    s = distance of the robot along the line, measured from c_xy (positive in the `heading`
    direction).  The robot drives forward if s < s_goal and reverses if s > s_goal, always
    keeping its body on `heading` (so backing out of a rack stays straight).
    """
    ch, sh = math.cos(heading), math.sin(heading)
    dx, dy = pose.x - c_xy[0], pose.y - c_xy[1]
    s = dx * ch + dy * sh
    e = -dx * sh + dy * ch                    # lateral error, left positive
    e_psi = wrap(pose.yaw - heading)
    ds = s_goal - s
    if abs(ds) < tol:
        return 0.0, 0.0, True
    v = clamp(1.5 * ds, -v_max, v_max)
    if abs(v) < 0.03:
        v = math.copysign(0.03, ds)
    w = clamp(-k_h * e_psi - math.copysign(1.0, v) * k_e * e, -w_max, w_max)
    return v, w, False
