#!/usr/bin/env python3
"""ROS 2 node that decodes QR codes and publishes the payload.

Subscribes:
    /camera/image_raw   (sensor_msgs/Image)
    /camera/camera_info (sensor_msgs/CameraInfo)  focal length, if available
    /qr_fast_mode       (std_msgs/Bool)           True = decode at --fast-rate
Publishes:
    /qr_detected        (std_msgs/String)  payload text (unchanged behaviour)
    /qr_detection       (std_msgs/String)  JSON with the plate POSITION:
                        {"text", "fwd", "left", "up", "bearing", "size_px",
                         "sec", "nanosec"}  -- fwd/left are metres relative to the
                        camera; game_manager uses them to dock with the rack.
                        Needs --qr-side (printed code size) to be right.

Offline check against a saved image:
    ros2 run qr_scanner qr_node --image /path/to/qr.png
"""

import argparse
import json
import math
import sys

import cv2
import rclpy
from rclpy.executors import ExternalShutdownException
from rclpy.node import Node
from rclpy.qos import qos_profile_sensor_data
from sensor_msgs.msg import CameraInfo, Image
from std_msgs.msg import Bool, String

from .decoder import decode_qr, decode_qr_ex
from .geometry import qr_pose


class QrScannerNode(Node):
    def __init__(self, image_topic, publish_topic, repeat=False, rate=5.0,
                 max_width=640, repeat_interval=2.0, qr_side=0.05,
                 pitch_up=0.10, hfov=1.0, fast_rate=8.0):
        super().__init__('qr_scanner')
        self._qr_side = qr_side
        self._pitch_up = pitch_up
        self._hfov = hfov
        self._slow_interval_ns = int(1e9 / rate) if rate > 0 else 0
        self._fast_interval_ns = int(1e9 / fast_rate) if fast_rate > 0 else 0
        self._fast = False
        self._intrinsics = None      # (fx, fy, cx, cy) from CameraInfo
        self._det_pub = self.create_publisher(String, '/qr_detection', 10)
        self.create_subscription(Bool, '/qr_fast_mode', self._on_fast, 10)
        self.create_subscription(CameraInfo, '/camera/camera_info',
                                 self._on_info, qos_profile_sensor_data)
        self._bridge = None
        self._last = None
        self._last_pub_ns = None
        self._repeat = repeat
        self._min_interval_ns = int(1e9 / rate) if rate > 0 else 0
        self._last_stamp_ns = None
        self._max_width = max_width
        self._repeat_interval_ns = int(repeat_interval * 1e9)
        self._publisher = self.create_publisher(String, publish_topic, 10)
        self._subscription = self.create_subscription(
            Image, image_topic, self._on_image, 10)
        self.get_logger().info(
            f'listening on {image_topic}, publishing {publish_topic}, '
            f'decoding at most {rate if rate > 0 else "unlimited"} Hz')

    def _on_fast(self, msg):
        # game_manager switches this on while it approaches / docks with a rack.
        if msg.data != self._fast:
            self._fast = msg.data
            self._min_interval_ns = (self._fast_interval_ns if self._fast
                                     else self._slow_interval_ns)
            self.get_logger().info(
                f'decode rate: {"fast" if self._fast else "normal"}')

    def _on_info(self, msg):
        if msg.k[0] > 1.0 and msg.k[4] > 1.0:
            self._intrinsics = (msg.k[0], msg.k[4], msg.k[2], msg.k[5])

    def _publish_geometry(self, text, corners, msg, frame):
        """Publish where the plate is, from its corners (pixel -> metres)."""
        height, width = frame.shape[:2]
        if self._intrinsics is not None:
            fx, fy, cx0, cy0 = self._intrinsics
        else:
            fx = (width / 2.0) / math.tan(self._hfov / 2.0)
            fy, cx0, cy0 = fx, width / 2.0, height / 2.0
        pose = qr_pose(corners, self._qr_side, fx, fy, cx0, cy0,
                       self._pitch_up)
        if pose is None:
            return
        pose.update({'text': text, 'sec': msg.header.stamp.sec,
                     'nanosec': msg.header.stamp.nanosec})
        self._det_pub.publish(String(data=json.dumps(pose)))

    def _on_image(self, msg):
        # Decoding every frame at 30 fps saturates the Pi; QR codes stay in
        # view long enough that a few Hz is plenty.
        if self._min_interval_ns:
            stamp_ns = self.get_clock().now().nanoseconds
            if (self._last_stamp_ns is not None
                    and stamp_ns - self._last_stamp_ns < self._min_interval_ns):
                return
            self._last_stamp_ns = stamp_ns

        from cv_bridge import CvBridge

        if self._bridge is None:
            self._bridge = CvBridge()
        try:
            frame = self._bridge.imgmsg_to_cv2(msg, desired_encoding='bgr8')
        except Exception as exc:  # malformed or unsupported encoding
            self.get_logger().warning(f'image conversion failed: {exc}')
            return

        try:
            text, corners = decode_qr_ex(frame, self._max_width)
        except Exception as exc:
            # Belt and braces: decoder.py already isolates OpenCV errors, but
            # the QR node must survive anything a camera frame can cause.
            self.get_logger().warning(
                f'decode failed: {exc}', throttle_duration_sec=5.0)
            return
        if not text:
            return
        if corners is not None:
            self._publish_geometry(text, corners, msg, frame)
        now_ns = self.get_clock().now().nanoseconds
        same_as_last = text == self._last
        if not self._repeat and same_as_last:
            # Re-publish a payload that is still in view, but slowly.  The
            # mission state machine may not be waiting for this tag the
            # first time it is seen (it often appears while the robot is
            # still driving towards the rack), so a payload published once
            # and never again would be missed.
            if (self._repeat_interval_ns == 0
                    or (self._last_pub_ns is not None
                        and now_ns - self._last_pub_ns
                        < self._repeat_interval_ns)):
                return
        self._last = text
        self._last_pub_ns = now_ns
        self._publisher.publish(String(data=text))
        if same_as_last:
            self.get_logger().debug(f'QR still in view: {text}')
        else:
            self.get_logger().info(f'QR detected: {text}')


def main(args=None):
    parser = argparse.ArgumentParser()
    parser.add_argument('--image', help='decode one image file and exit')
    parser.add_argument('--image-topic', default='/camera/image_raw')
    parser.add_argument('--publish-topic', default='/qr_detected')
    parser.add_argument('--rate', type=float, default=5.0,
                        help='max decode attempts per second (0 = unlimited)')
    parser.add_argument('--max-width', type=int, default=640,
                        help='downscale frames wider than this before decoding')
    parser.add_argument('--qr-side', type=float, default=0.05,
                        help='side of the printed QR code (black/white part, '
                             'metres).  MEASURE IT: distances scale with it')
    parser.add_argument('--pitch-up', type=float, default=0.10,
                        help='camera tilt upwards [rad] (robot_bringup '
                             'camera_pitch is minus this)')
    parser.add_argument('--hfov', type=float, default=1.0,
                        help='horizontal field of view [rad] used when no '
                             'CameraInfo is published')
    parser.add_argument('--fast-rate', type=float, default=8.0,
                        help='decode rate while /qr_fast_mode is true')
    parser.add_argument('--repeat', action='store_true',
                        help='publish the same payload every frame')
    parser.add_argument('--repeat-interval', type=float, default=2.0,
                        help='seconds between re-publishes of a payload '
                             'that is still in view (0 = only on change)')
    parsed, ros_args = parser.parse_known_args(args)

    if parsed.image:
        frame = cv2.imread(parsed.image)
        if frame is None:
            print(f'cannot read {parsed.image}')
            return 1
        text = decode_qr(frame, parsed.max_width)
        print(text if text else 'NO_QR_FOUND')
        return 0 if text else 1

    rclpy.init(args=ros_args)
    node = QrScannerNode(
        parsed.image_topic, parsed.publish_topic, parsed.repeat,
        parsed.rate, parsed.max_width, parsed.repeat_interval,
        parsed.qr_side, parsed.pitch_up, parsed.hfov, parsed.fast_rate)
    try:
        rclpy.spin(node)
    except (KeyboardInterrupt, ExternalShutdownException):
        pass
    finally:
        node.destroy_node()
        if rclpy.ok():
            rclpy.shutdown()
    return 0


if __name__ == '__main__':
    sys.exit(main())
