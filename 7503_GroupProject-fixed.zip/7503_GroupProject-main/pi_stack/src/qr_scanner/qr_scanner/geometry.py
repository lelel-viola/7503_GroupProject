"""Where is the QR plate?  (pose of a square code of known size from its 4 corners)

Uses solvePnP on the plate's four corners, which stays accurate when the plate is seen
at an angle.  Plain "apparent size" ranging would be biased by 10-15 % because the camera
looks UP at the plates (they sit above the camera), so the plate is foreshortened.
"""
import math

import cv2
import numpy as np


def qr_pose(corners, qr_side, fx, fy, cx0, cy0, pitch_up=0.0):
    """Return a dict with the plate position relative to the camera, or None.

    corners  : 4x2 pixel corners ordered TL, TR, BR, BL (see decoder.order_corners)
    qr_side  : side length of the black/white code [m], WITHOUT the white border
    fx, fy, cx0, cy0 : camera intrinsics in pixels
    pitch_up : camera tilt upwards [rad]

    fwd  : horizontal distance ahead of the camera [m]
    left : lateral offset, left positive [m]
    up   : height above the camera [m]
    bearing = atan2(left, fwd) [rad], size_px = mean edge length in the image
    """
    quad = np.asarray(corners, dtype=float).reshape(4, 2)
    size_px = float(np.mean([np.linalg.norm(quad[i] - quad[(i + 1) % 4])
                             for i in range(4)]))
    if size_px < 8.0:
        return None
    half = qr_side / 2.0
    obj = np.array([[-half, half, 0], [half, half, 0],
                    [half, -half, 0], [-half, -half, 0]], np.float32)
    k = np.array([[fx, 0, cx0], [0, fy, cy0], [0, 0, 1.0]])
    ok, _rvec, tvec = cv2.solvePnP(obj, quad.astype(np.float32), k, None,
                                   flags=cv2.SOLVEPNP_IPPE_SQUARE)
    if ok and tvec[2, 0] > 0:
        x_right, y_down, z = (float(tvec[0, 0]), float(tvec[1, 0]),
                              float(tvec[2, 0]))
    else:                                    # fallback: apparent size
        z = fx * qr_side / size_px
        x_right = (quad[:, 0].mean() - cx0) / fx * z
        y_down = (quad[:, 1].mean() - cy0) / fy * z
    fwd = z * math.cos(pitch_up) + y_down * math.sin(pitch_up)
    up = z * math.sin(pitch_up) - y_down * math.cos(pitch_up)
    left = -x_right
    return {'fwd': fwd, 'left': left, 'up': up,
            'bearing': math.atan2(left, fwd), 'size_px': size_px}
