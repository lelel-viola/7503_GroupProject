#!/usr/bin/env python3
"""Generate game_manager/config/game_params.yaml from the rack centres.

Edit RACK_CENTRES below (or pass --centres) after measuring the real field with a
tape measure, then run

    python3 tools/make_game_params.py            # writes the yaml, prints a clearance table
    python3 tools/make_game_params.py --check    # only print the table

The script derives, for every rack,
  * the Nav2 APPROACH pose  - robot stops with the rack's QR plate `approach_range`
                              metres in front of the camera, heading -x (towards the
                              destination), i.e. on the START side of the rack;
  * the docking line        - rack centre + direction the robot drives into it;
and for every delivery
  * the drop pose           - robot (= rack) centre when the rack is released;
  * the staging pose        - `stage_distance` m behind the drop pose.
Then it checks the 0.32 x 0.32 m robot footprint against the walls and the racks that
are standing there at that moment, so a layout that cannot work is reported here and
not on the field.

Frame: map frame of the course drawing -- origin bottom-left, x from the destination
(x = 0) towards the START zone (x = 3.02), y up, right handed.  Seen from the START
zone looking at the destination, A and D are on the robot's LEFT (small y).
"""
import argparse
import math
import os
import sys

FIELD = (3.02, 2.00)
DEST_ZONE = (0.0, 0.8, 0.3, 1.7)          # x_min, x_max, y_min, y_max
FOOTPRINT = 0.16                          # half-size of the 0.32 m square Nav2 footprint

# ----------------------------------------------------------------- measured / estimated data
# Rack centres (x, y) in metres.  ESTIMATES from the course drawing + Game Field Map +
# demo video.  >>> MEASURE THEM ON THE REAL FIELD <<<
RACK_CENTRES = {
    'A': (1.130, 0.525),
    'B': (1.830, 1.385),
    'C': (1.320, 1.695),
    'D': (1.920, 0.385),
}
RACK_DEPTH = 0.14        # x extent (the QR face is on the +x side, towards START)
RACK_WIDTH = 0.35        # y extent, legs included
PLATE_TO_CENTER = 0.074  # QR plate (front face) -> rack centre  (depth / 2 + plate thickness)
CAMERA_FORWARD = 0.12    # camera x offset from base_link (robot_bringup camera_x)
# Camera -> plate distance at the Nav2 goal.  A is approached closer because rack D (picked
# last) stands in its lane only ~0.7 m away; B, C, D are picked after their neighbours left.
APPROACH_RANGE = {'A': 0.25, 'B': 0.40, 'C': 0.40, 'D': 0.40}
APPROACH_DY = {'A': 0.0, 'B': 0.0, 'C': 0.0, 'D': 0.0}           # optional sidestep per rack
STOP_RANGE = 0.30        # visual servo stops when the plate is this far ahead of the camera
STAGE_DISTANCE = 0.35
# Drop centres, filled in this order (A, B, C, D).  Rack footprint stays inside the zone.
SLOTS = [(0.20, 0.52), (0.20, 1.48), (0.55, 0.52), (0.55, 1.48)]
ORDER = ['A', 'B', 'C', 'D']


def rack_box(cx, cy):
    return (cx - RACK_DEPTH / 2, cx + RACK_DEPTH / 2, cy - RACK_WIDTH / 2, cy + RACK_WIDTH / 2)


def footprint_clearance(x, y, yaw, boxes):
    """Smallest gap (m) between the robot square and walls / boxes; negative = overlap."""
    c, s = math.cos(yaw), math.sin(yaw)
    pts = []
    n = 41
    for i in range(n):
        t = -FOOTPRINT + 2 * FOOTPRINT * i / (n - 1)
        pts += [(FOOTPRINT, t), (-FOOTPRINT, t), (t, FOOTPRINT), (t, -FOOTPRINT)]
    best = 1e9
    for px, py in pts:
        wx, wy = x + c * px - s * py, y + s * px + c * py
        best = min(best, wx, FIELD[0] - wx, wy, FIELD[1] - wy)
        for (x0, x1, y0, y1) in boxes:
            dx = max(x0 - wx, 0.0, wx - x1)
            dy = max(y0 - wy, 0.0, wy - y1)
            if dx == 0.0 and dy == 0.0:
                inside = min(wx - x0, x1 - wx, wy - y0, y1 - wy)
                best = min(best, -inside)
            else:
                best = min(best, math.hypot(dx, dy))
    return best


def derive(centres):
    out = {'approach': {}, 'slots': []}
    for k in ORDER:
        cx, cy = centres[k]
        x = cx + PLATE_TO_CENTER + CAMERA_FORWARD + APPROACH_RANGE[k]
        y = cy + APPROACH_DY[k]
        out['approach'][k] = (round(x, 3), round(y, 3), math.pi)
    for (sx, sy) in SLOTS:
        out['slots'].append({'drop': (sx, sy, math.pi), 'stage': (round(sx + STAGE_DISTANCE, 3), sy, math.pi)})
    return out


def check(centres, d):
    rows, ok = [], True
    for i, k in enumerate(ORDER):
        later = [rack_box(*centres[j]) for j in ORDER[i:]]            # still standing (incl. target)
        done = [rack_box(*SLOTS[j]) for j in range(i)]                # already delivered
        x, y, yaw = d['approach'][k]
        rows.append((f'approach {k}', x, y, footprint_clearance(x, y, yaw, later + done)))
        sl = d['slots'][i]
        others = [rack_box(*centres[j]) for j in ORDER[i + 1:]] + done
        for tag in ('stage', 'drop'):
            x, y, yaw = sl[tag]
            rows.append((f'{tag} slot {i + 1}', x, y, footprint_clearance(x, y, yaw, others)))
        bx = rack_box(*SLOTS[i])
        if not (DEST_ZONE[0] <= bx[0] and bx[1] <= DEST_ZONE[1] and DEST_ZONE[2] <= bx[2] and bx[3] <= DEST_ZONE[3]):
            print(f'  !! slot {i + 1}: the rack footprint is not inside the destination zone')
            ok = False
    print(f'{"pose":<16}{"x":>7}{"y":>7}   clearance (m)')
    for name, x, y, c in rows:
        flag = 'COLLIDES' if c < 0 else ('tight' if c < 0.03 else 'ok')
        if c < 0:
            ok = False
        print(f'{name:<16}{x:7.3f}{y:7.3f}   {c:7.3f}  {flag}')
    return ok


def fmt(v):
    return f'{v:.4f}'


def write_yaml(path, centres, d):
    lines = []
    w = lines.append
    w('# AUTO-GENERATED by tools/make_game_params.py -- edit the script, not this file.')
    w('#')
    w('# Frame: map frame of the course drawing (origin bottom-left, x from the destination')
    w('# towards START, y up).  Seen from START looking at the destination, A and D are on the')
    w('# robot\'s left (small y).')
    w('#')
    w('# Racks are portal frames 0.14 (x) x 0.35 (y) m.  The QR plate is on the face that points')
    w('# towards START (+x).  The robot therefore:')
    w('#   1. drives (Nav2) to the APPROACH pose, on the START side, facing -x;')
    w('#   2. centres on the QR plate (visual servo), then drives under the rack (DOCK_RACK);')
    w('#   3. lifts, drives (Nav2) to the STAGING pose in front of its drop slot;')
    w('#   4. drives into the slot (DOCK_SLOT), lowers the lift, backs out (EXIT_SLOT).')
    w('# The rack_*_cx/cy centres below are only a fallback for docking when the QR geometry is')
    w('# not available; with a readable QR the measured plate position is used instead.')
    w('game_manager:')
    w('  ros__parameters:')
    w('    use_nav2: true')
    w('    # set_initial_pose: publish /initialpose when START is scanned (AMCL).')
    w('    set_initial_pose: false')
    w('    dry_run_travel_time: 3.0')
    w('')
    w('    mission_timeout: 180.0')
    w('    rack_scan_timeout: 15.0')
    w('    end_scan_timeout: 20.0')
    w('    lift_time: 1.5')
    w('    rack_order: "A,B,C,D"')
    w('    require_end_qr: true')
    w('    end_qr_stops_mission: false')
    w('    strict_rack_match: true')
    w('    rack_qr_cache_time: 30.0')
    w('')
    w('    start_x: 2.72')
    w('    start_y: 1.00')
    w('    start_yaw: 3.1416')
    w('    destination_x: 0.40')
    w('    destination_y: 1.00')
    w('    destination_yaw: 3.1416')
    w('')
    w('    # ---- docking (new) -------------------------------------------------------')
    w('    use_docking: true            # false = old behaviour: lift at the approach pose')
    w('    rack_front_yaw: 0.0          # direction the QR face points to (0 = +x, towards START)')
    w(f'    plate_to_center: {fmt(PLATE_TO_CENTER)}       # QR plate -> rack centre [m]')
    w(f'    camera_forward: {fmt(CAMERA_FORWARD)}         # camera x on base_link [m] (robot_bringup camera_x)')
    w(f'    stop_range: {fmt(STOP_RANGE)}             # servo stops with the plate this far ahead of the camera [m]')
    w('    lift_offset: 0.0             # lift centre ahead of base_link centre [m]')
    w(f'    stage_distance: {fmt(STAGE_DISTANCE)}         # staging pose is this far behind the drop pose [m]')
    w('    dock_timeout: 25.0           # give up a rack / slot docking after this many seconds')
    w('    servo_acquire_timeout: 2.5   # no QR geometry for this long -> dock on the nominal centre')
    w('    v_servo: 0.08                # m/s while centring on the QR plate')
    w('    v_line: 0.10                 # m/s while driving into / out of a rack')
    w('    v_exit: 0.12                 # m/s while backing out of a slot')
    w('    dry_run_dock_time: 1.5')
    w('    end_scan_spin_w: 0.5         # rad/s: turn in place while waiting for END (0 = off)')
    w('    rack_scan_sweep_w: 0.35      # rad/s: sweep +-0.5 rad if the QR is not in view (0 = off)')
    w('    rack_scan_sweep_delay: 2.0   # s without the QR before the sweep starts')
    w('    rack_scan_sweep_period: 1.5  # s per sweep leg')
    w('')
    w('    # One drop pose per delivery (robot centre = rack centre), in delivery order.')
    pts = '; '.join(f'{s["drop"][0]:.3f},{s["drop"][1]:.3f},{s["drop"][2]:.4f}' for s in d['slots'])
    w(f'    destination_points: "{pts}"')
    w('')
    w('    # Nominal rack centres (fallback for docking) and Nav2 approach poses.')
    for k in ORDER:
        cx, cy = centres[k]
        x, y, yaw = d['approach'][k]
        low = k.lower()
        w(f'    rack_{low}_cx: {fmt(cx)}')
        w(f'    rack_{low}_cy: {fmt(cy)}')
        w(f'    rack_{low}_x: {fmt(x)}')
        w(f'    rack_{low}_y: {fmt(y)}')
        w(f'    rack_{low}_yaw: {fmt(yaw)}')
    with open(path, 'w') as f:
        f.write('\n'.join(lines) + '\n')


def main():
    here = os.path.dirname(os.path.abspath(__file__))
    default_out = os.path.join(here, '..', 'src', 'game_manager', 'config', 'game_params.yaml')
    ap = argparse.ArgumentParser()
    ap.add_argument('--out', default=default_out)
    ap.add_argument('--check', action='store_true', help='print the clearance table only')
    ap.add_argument('--centres', help='A:x,y;B:x,y;C:x,y;D:x,y (metres) overriding RACK_CENTRES')
    args = ap.parse_args()
    centres = dict(RACK_CENTRES)
    if args.centres:
        for item in args.centres.split(';'):
            k, v = item.split(':')
            centres[k.strip().upper()] = tuple(float(t) for t in v.split(','))
    d = derive(centres)
    ok = check(centres, d)
    if not args.check:
        write_yaml(args.out, centres, d)
        print(f'\nwrote {os.path.normpath(args.out)}')
    if not ok:
        print('\nWARNING: some poses collide - adjust APPROACH_RANGE / APPROACH_DY / SLOTS in this script')
        return 1
    print('\nlayout OK')
    return 0


if __name__ == '__main__':
    sys.exit(main())
