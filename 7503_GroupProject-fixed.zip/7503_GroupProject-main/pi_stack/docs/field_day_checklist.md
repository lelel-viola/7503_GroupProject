# 场地日清单

在真实场地上按顺序要做的事，以及判断每一步是否真正成功的验收标准。以下所有内容都在树莓派（`rsi-bd-11`）上运行；命令假设两个工作区都已 source：

```bash
source /opt/ros/jazzy/setup.bash
source ~/camera_ws/install3/setup.bash
source ~/lidar_ros_ws/install/setup.bash
```

## 0. 离开桌面之前

* 桌面排练通过：4 次投放，得分 20，97 秒（`docs/rehearsal_2026-10-18.md`）。
* 带上：卷尺（5 m）、美纹纸、一张中心安装在 232.5 mm 高的打印二维码标签、充电器、手机热点。
* 给树莓派充电，并检查 SD 卡没有满（`df -h /`）。

## 1. 启动传感器

```bash
ros2 launch robot_bringup robot_bringup.launch.py
```

带底盘时用 `publish_odom_tf:=true`；在桌面上用 `fake_base` 时保持 false（见 `docs/micro_ros_contract.md`）。

验收：

```bash
ros2 topic hz /scan                # ~10 Hz
ros2 topic hz /camera/image_raw    # ~10 Hz（Foxglove 推流时 >= 5 Hz）
ros2 node list | grep lidar_watchdog
ros2 run tf2_ros tf2_echo base_link camera
# translation (0.120, 0.000, 0.170), pitch -5.73 deg
```

`lidar_watchdog` 在 `/scan` 停止 5 秒后重发 MS200 启动命令，数据恢复时记录 `lidar stream recovered`。USB 重枚举时它救不了：`/dev/oradar` 会指向新的 `ttyACM*`，而驱动仍抱着已删除的旧 tty。怀疑雷达之前，先对比 `readlink /dev/oradar` 与 `ls -l /proc/$(pgrep -f oradar_scan)/fd`；不一致就重启整栈。`dmesg` 里反复出现 `over-current change` 说明是线缆或接头短路，不是软件；没有过流日志、只有一条 `USB disconnect` 也仍然是重枚举，所以先查 tty 是否一致，别把“没有过流”当成正常。

## 2. 用雷达给场地建图（底盘还不存在时）

AMCL 必须把真实场地与地图匹配起来。Cartographer 不需要轮式里程计，所以可以在手动推车时运行。

```bash
ros2 launch robot_navigation cartographer_mapping.launch.py
```

推着机器人绕场地慢慢走（约 0.2 m/s）：沿四面墙各走一遍，然后绕货架一圈，最后回到起点区。让雷达与墙保持 0.3–1.5 m；不要原地旋转超过约 30 度/秒。

保存并转换：

```bash
ros2 service call /write_state cartographer_ros_msgs/srv/WriteState \
  "{filename: '/home/rsi-bd-11/field_map.pbstream', include_unfinished_submaps: true}"

ros2 run cartographer_ros cartographer_pbstream_to_ros_map \
  -pbstream_filename=$HOME/field_map.pbstream \
  -map_filestem=$HOME/field_map -resolution=0.05
```

验收：

* `field_map.pgm` 显示四面直墙和货架轮廓，没有重影墙（有重影墙说明扫描匹配滑了——用更慢的速度重走一圈）。
* 量出的墙到墙尺寸是 3020 x 2000 mm（0.05 m 下 60 x 40 格，再加一点边距）。
* 地图能在 Nav2 中加载，机器人在起点区的位姿 (2.72, 1.00) 位于地图的自由空间内，朝向场地。

**启动 Nav2 之前先停掉 Cartographer。** 两者都发布 `/map`；残留的 `cartographer_occupancy_grid_node` 会替换静态场地图，规划器随后从所有位姿都失败：

```bash
pgrep -af cartographer               # 必须没有任何输出
ros2 topic info /map                 # Nav2 启动后 Publisher count: 1
```

## 3. 在场地图上定位

```bash
ros2 launch robot_navigation navigation.launch.py map:=$HOME/field_map.yaml
```

AMCL 从 `nav2_params.yaml` 里配置的起点区位姿开始（`initial_pose: 2.72, 1.00, yaw 3.1416`）。把机器人实际停在起点区、朝向场地，在 RViz 里检查收敛情况（`/amcl_pose` 和粒子云）。

如果位姿不对，要么修正地图原点，要么手动设置初始位姿；在 `map -> base_link` 看起来正确之前，不要让 `game_manager` 启动。

验收：

```bash
ros2 run tf2_ros tf2_echo map base_link     # 有限值，且在场地范围内
```

## 4. 相机 / 二维码标签几何

标签中心距场地地面 232.5 mm；相机光心在 170 mm，向上倾斜 5.73 度。在 0.25–0.40 m 接近距离处，标签大约在水平线上方 10–15 度，即光轴上方约 5–10 度——应该在画面内。要实测，不要只相信计算：

1. 把打印好的二维码标签（`RACKA_…`）放到货架上，中心正好离地 232.5 mm。
2. 把机器人停在接近位姿（`tools/make_game_params.py` 打印的 approach 表：相机离标签 0.25–0.40 m）。
3. `ros2 topic echo /qr_detected` 必须在 1 秒内打印出内容。
4. 把标签上移 50 mm 和下移 50 mm 各重复一次：内容仍必须能解出，因为真实货架和地面有差异。

如果标签在画面顶部被切掉，抬高相机或增大 `robot_bringup.launch.py` 里的俯仰角；如果在底部被切掉，降低相机。之后重新检查 TF。

实测解码距离（填写）：______ m。最小可靠距离：______ m。

## 5. 标定货架位姿（必做，这是整套逻辑能不能跑通的前提）

货架是 **140 x 350 mm 的龙门架**（x 方向 140、y 方向 350），**二维码标签在朝起点一侧（+x）的那一面**。
机器人从起点这一侧正对着开过去（朝向 -x），再钻进货架。旧版本把货架当成 150 x 140 的小方块、从侧面接近，已更正。

1. **先确认左右**：站在起点区面向目的区，**A、D 应该在你的左手边，B、C 在右手边**；A、C 靠近目的区，D、B 靠近起点区。
   （从课程示意图、演示视频、图纸尺寸链交叉得到；左右那一条请务必现场确认。如果是反的，把 y 换成 `2.0 - y`。）
2. 用卷尺量每个货架 **中心** 的坐标（`map` 坐标系：x = 到**目的区那面短墙**的距离；
   y = 到**长墙**的距离，且这面长墙是 **站在起点区面向目的区时你左手边的那一面**，所以 A、D 的 y 小，B、C 的 y 大），填到下表。
   现场 10 秒自检：A 的端头到左手边长墙约 **0.35 m**，D 的端头到同一面墙约 **0.21 m**（视频估算 0.36 / 0.25 m）；
   差得很多（例如 A 只有约 0.13 m、D 约 0.44 m）就说明我的估计不对，以卷尺实测为准。

| 货架 | 估计中心 (x, y) | 实测中心 (x, y) |
| --- | --- | --- |
| A | 1.130, 0.525 | |
| B | 1.830, 1.385 | |
| C | 1.320, 1.695 | |
| D | 1.920, 0.385 | |

3. 把实测值写进 `tools/make_game_params.py` 的 `RACK_CENTRES`（或 `--centres "A:x,y;B:x,y;C:x,y;D:x,y"`），运行：

```bash
cd ~/dase7503_repo/pi_stack        # 仓库里的 pi_stack 目录
python3 tools/make_game_params.py  # 重写 game_params.yaml，并打印"车体 vs 墙/货架"的间隙表
```

   间隙表出现 `COLLIDES` 说明这个布局下某个接近点撞货架，调整脚本里的 `APPROACH_RANGE` / `APPROACH_DY` 再生成。
   已知：A 的正前方有 D，所以 A 的接近距离只有 0.25 m；A 的坐标越准越好。
4. 重新 `colcon build`（或 `--symlink-install` 已经生效），在每个接近位姿处运行 `ros2 run tf2_ros tf2_echo map base_link`，与卷尺结果相差不超过 50 mm。

接近位姿**不再**只是"离货架 0.35 m"：它在货架的起点一侧，相机离标签 0.25–0.40 m，之后由 `DOCK_RACK`（二维码视觉伺服 + 沿线进入）负责最后 40 cm。
`rack_qr_cache_time` 的缓存只用于"到达前已经读到码"的情况；对位时必须能看到当前货架的标签，否则会放弃该货架而不是盲钻。

## 6. 运行比赛栈

一条命令（传感器已经启动时会跳过）：

```bash
~/lidar_ros_ws/install/robot_bringup/lib/robot_bringup/start_match.sh \
    --map ~/field_map.yaml
```

带底盘时加 `--odom-tf`，让 `/odom` 广播为 TF。加 `--rviz` 可在树莓派显示器上观看；或者加 `--foxglove`，从笔记本用 Foxglove 桌面版 3.x 连接 `ws://<pi-ip>:8765`（旧版 Studio 只支持 `foxglove.websocket.v1`，3.x 桥接会拒绝）。Ctrl-C 停止整个栈。不用脚本时：

```bash
ros2 launch game_manager game_manager.launch.py
```

观察 `/game_state`、`/game_score` 和 `/lift_cmd`。现场 START 二维码从标签读取；不使用 supervisor。

完整运行的验收：

* 四个货架全部抬起并送达，得分 20；
* Nav2 日志中没有规划器或控制器失败；
* 用时低于 150 秒（桌面排练：97 秒），在 180 秒比赛限制内留出余量；
* END 之后机器人自己停在投放区。

## 7. 时间预算

| 阶段 | 桌面 | 现场允许 |
| --- | --- | --- |
| 传感器启动 | 15 s | 30 s |
| START -> 货架 A | 9.7 s | 15 s |
| 货架 -> 投放区 | 9.1 s | 15 s |
| 完整任务 | 97 s | 150 s |

如果现场运行超过 150 秒，先提高 `nav2_params.yaml` 里的速度限制（`max_vel_x`、`max_speed_xy`），再考虑改动货架顺序：场地只有 3 m 宽，大部分时间都花在行驶上。
