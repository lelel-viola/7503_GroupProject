# 修复说明（2026-11）：自动导航到 A→B→C→D 并取货放货

结论：原来的状态机**按 A→B→C→D 的顺序**走是对的，但货架坐标、货架尺寸/朝向、取货动作、底盘接口有问题，
真车上基本跑不通。本次修改的目标是让"逻辑上能跑通"的东西也"几何上能跑通"。

## 1. 发现的问题和依据

### 1.1 货架 C、D 的位置互换（高置信度）
课程示意图（Game Field Map，带字母）、物理场地照片和演示视频都显示：

* **A、C 靠近目的区，D、B 靠近起点区**；A 和 D 在同一侧墙边，B 和 C 在另一侧。
* 视频里 "Scan the Rack D QR code" 的画面中，D **紧挨着 START 立柱**。

原配置：A (1.275, 1.580)、D (1.325, 0.200) 靠近目的区；B (1.825, 0.510)、C (1.925, 1.720) 远离目的区——
**C 和 D 的 x 反了**（相差约 0.6 m），与示意图矛盾。这一点与坐标系左右手无关。

### 1.2 货架尺寸与朝向（高置信度）
* 货架是**龙门架，140 mm（x，深）x 350 mm（y，宽）**。示意图里的黄色矩形是 357 x 109 mm，图纸标注 `350.00` 和 `140.00` 对应这两个尺寸。
  原配置按 150 x 140 mm 的小方块处理。
* **二维码标签在朝起点一侧（+x）的那一面**，机器人从起点这一侧正对着开过去（视频、照片均如此）。
  原配置从 ±y 方向（货架的短边端头）接近，相机根本看不到标签，而且接近位姿的车体与货架重叠。

### 1.3 货架左右（中等置信度，请现场确认）
示意图里的货架位置换算到图纸坐标系后，与图纸尺寸链推出的 4 个图标位置吻合到 13–23 mm（镜像换算），旋转换算则差约 1 m。
也就是说示意图与图纸坐标是镜像关系。视频里测得货架端头到侧墙的间距 A ≈ 0.36 m、D ≈ 0.25 m，
与"A、D 在 y 小的一侧"的估计（A 0.35 m、D 0.21 m）吻合，与另一种解释（A 0.13 m、D 0.44 m）不吻合。
所以估计的真实中心（map 坐标，原点在左下角，x 向起点，y 向上）：

| 货架 | 估计中心 | 原配置 |
| --- | --- | --- |
| A | (1.130, 0.525) | (1.275, 1.580) |
| B | (1.830, 1.385) | (1.825, 0.510) |
| C | (1.320, 1.695) | (1.925, 1.720) |
| D | (1.920, 0.385) | (1.325, 0.200) |

**这些是估计值，不是实测。** `docs/field_day_checklist.md` 第 5 节给了 10 秒自检和量法。

### 1.4 取货没有闭环
原流程：Nav2 开到"离货架 0.35 m"，然后发 `/lift_cmd up`。机器人从来没有钻进货架；`/lift_cmd` 也没有任何节点订阅
（固件只有 `servo_s1/s2` 的 `Int32`）。

### 1.5 底盘接口与固件不一致
* 固件把里程计发在 `odom_raw`，坐标系 `odom_frame` → `base_footprint`，时间戳来自 agent 时钟（固件没调 `rmw_uros_sync_session`，
  时间戳是"开机以来的秒数"）。`odom_to_tf` 和 Nav2 订阅的是 `/odom`。真车上没有 `/odom`，也没有 TF，Nav2 起不来。
* 固件没有 `cmd_vel` 超时。底盘通过 WiFi 连接，一旦断线或 Nav2 崩溃，小车保持最后一条速度继续开（碰撞扣分，也不安全）。

### 1.6 投放槽位放不下
货架 0.35 m 宽，原来 4 个投放点沿 y 排一列（0.45 … 1.62），首尾货架会超出目的区（y 0.30–1.70）。整个目的区 1.4 m 宽，一列也放不下 4 个。

### 1.7 排练只验证了一部分
`desk_mode` 关了雷达避障、冻结 AMCL、用 `fake_base`，二维码由 `mission_supervisor` 在到达时注入。
它证明了状态机顺序和 Nav2 action 衔接，没有证明定位、避障、读码。（他们自己的文档也写了这一点。）

## 2. 修改了什么

| 位置 | 修改 |
| --- | --- |
| `pi_stack/tools/make_game_params.py` **（新）** | 输入 4 个货架中心，生成 `game_params.yaml`：接近位姿（START 侧、朝 -x）、2x2 投放槽位和停靠点；并检查车体与墙/其余货架的间隙（考虑"此刻哪些货架已被搬走"），有碰撞就报错 |
| `game_manager/config/game_params.yaml` | 由上面的脚本重新生成；新增 `use_docking`、`stop_range`、`stage_distance`、`v_servo` 等参数 |
| `game_manager/game_manager/motion.py` **（新）** | 视觉伺服 `servo_cmd`、沿线行驶 `line_cmd`（前进/倒车都保持车身朝向） |
| `game_manager/game_manager/game_manager_node.py` | 新增状态 `DOCK_RACK`（二维码视觉伺服 → 沿货架法线开到货架正中）、`DOCK_SLOT`（沿线开进投放槽）、`EXIT_SLOT`（倒出）；二维码看不到时左右扫视；等 END 时原地慢转找码；到不了投放点时不再结束整场比赛，而是就地放下继续下一个；`use_docking:=false` 恢复旧行为 |
| `qr_scanner/decoder.py`、`geometry.py` **（新）**、`qr_node.py` | 解码时同时返回四个角点；用 `solvePnP` 算出标签相对相机的 `fwd/left/up/bearing`，发布到 `/qr_detection`（JSON）；`/qr_fast_mode` 切换 3 Hz / 8 Hz 解码；640 宽的图也做 2x 放大候选（0.45 m 处成功率 83%→100%）；读 `CameraInfo` 的焦距 |
| `robot_bringup/scripts/odom_to_tf.py` | 订阅 `/odom_raw`，发布修正后的 `/odom`（坐标系 `odom`→`base_link`）和 TF；时间戳改用树莓派时钟 |
| `robot_bringup/scripts/lift_bridge.py` **（新）** | `/lift_cmd` 的 `up`/`down` → `servo_s1` 角度（默认 90 / 50，来自键盘遥控的 z/c 键，**升降方向需上机核对**） |
| `robot_bringup/launch`、`CMakeLists.txt`、`scripts/start_match.sh` | 接入 lift_bridge；新增 `--qr-side`、`--no-docking` 选项；相机俯仰角传给二维码节点 |
| `robot_navigation/config/nav2_params.yaml` | AMCL 和障碍层忽略 0.30 m 以内的回波（抬着的货架腿）；碰撞监视器改用 ±0.13 m 的窄多边形（货架腿在 0.15–0.18 m 处，否则抬起货架后小车会被自己的货架"冻住"） |
| `robot_navigation/maps/field.pgm`、`tools/make_field_map.py` | 静态图只画墙，不再画货架（货架会被搬走，画进去就是幽灵障碍） |
| `chassis_firmware/main/main.c` | 加 500 ms `cmd_vel` 超时（定时器里检查，agent 掉线也会停车）；`rmw_uros_sync_session` 后再取时间 |
| `docs/*`、`RUN_GUIDE.md` | 更新旧坐标，新增检查表步骤和运行指南 |
| `pi_stack/tests/` **（新）** | 不需要 ROS 的测试（见下） |

## 3. 新的流程

```
WAIT_START ─START─► DRIVE_TO_RACK ─► WAIT_RACK_QR ─RACKx_─► DOCK_RACK ─► LIFT_UP
   (在起点 START 侧, 朝 -x,        (看不到就左右扫视)   (视觉伺服+沿线      │
    相机离标签 0.25–0.40 m)                              钻进货架)           ▼
                                                                       DRIVE_TO_DEST (停靠点, 投放点后 0.35 m)
 ... ◄─ EXIT_SLOT ◄─ LIFT_DOWN ◄─ DOCK_SLOT (沿线开进槽位) ◄────────────────┘
```

## 4. 验证了什么、没验证什么

在没有 ROS 的环境里用假世界验证（`tests/`）：

| 测试 | 结果 |
| --- | --- |
| `test_game_manager_sim.py`：**真正的** `game_manager_node.py` 在运动学假世界里跑 7 个场景 | 全部符合预期：标准场景 4/4 送达、0 碰撞；货架提示偏 8 cm、没有二维码几何（用名义中心）、车体只有 1.5 cm 余量、Nav2 第一次失败重试，均为 4/4；C/D 提示互换时跳过而不乱抬（A、B 送达）；**原配置在同一块场地上 0 个送达** |
| `test_qr_geometry.py`：5 cm 二维码经 640x480 针孔相机投影后解码 + `solvePnP` | 0.45 m 内误差 fwd < 1 cm、left < 0.3 cm；0.45 m 内无解码失败；0.55 m 开始不可靠（5 cm 的码） |

没有验证（请上机）：

* **固件**：改动没编译、没烧录（环境里没有 ESP-IDF）。改动很小（在 `main.c` 里搜索 `CMD_VEL_TIMEOUT_MS` 和 `rmw_uros_sync_session`），但需要你们编译确认。
* **真实 Nav2/AMCL/雷达/相机**：假世界里 Nav2 是"瞬移 + 到达误差"，没有避障和定位。
* **升降机构**：`s1_up / s1_down` 的方向和角度；升降是否真的把货架顶离地面；机器人能否真的从货架两腿之间通过（假世界按车宽 0.26 m、货架腿内净宽 0.31 m 假设）。
* **货架实际坐标和左右**（见 1.3）、**二维码实际边长**（默认 0.05 m）、相机视场角和安装位置。
* **时间**：假世界里 4 个货架分别在约 28、72、116、161 s 送达，**余量只有约 20 s**。真车比这慢的话只能送 3 个；
  可以在 `game_params.yaml` 里把 `v_servo`、`v_line` 提高，或提高 DWB 的 `max_vel_x`。

## 5. 已知的限制

* A 的正前方 0.7 m 处就是 D（取 A 时 D 还在场上），所以 A 的接近距离只有 0.25 m，余量约 11 cm。A 的坐标要量准。
* `/qr_detection` 的距离与 `qr_side` 成正比，量错二维码边长，进货架的距离就会错。
* 货架内净宽只比车宽大 1–3 cm 的话，需要小心调 `v_servo`；伺服在二维码出画面后改用"中位数标签位置"继续控制，不依赖最后一帧。
* 里程计时间戳用树莓派时钟（`use_pi_clock`），不依赖固件的时间同步。
