"""QR decode + plate position on synthetic camera frames (640x480, 5 cm plate).

    cd pi_stack && python3 tests/test_qr_geometry.py

Renders a QR code through a pinhole camera that looks slightly UP (like the robot's camera),
adds blur and noise, then checks decode_qr_ex() + qr_pose() against the true position.
"""
import math
import os
import sys

import cv2
import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(os.path.dirname(HERE), 'src', 'qr_scanner'))
from qr_scanner.decoder import decode_qr, decode_qr_ex  # noqa: E402
from qr_scanner.geometry import qr_pose  # noqa: E402

W, H, HFOV, PITCH, QR = 640, 480, 1.0, 0.10, 0.05
FX = (W / 2) / math.tan(HFOV / 2)
CAM_Z, PLATE_Z = 0.17, 0.2325


def make_tex(text, modules_px=12, quiet=4):
    code = cv2.QRCodeEncoder.create().encode(text)[2:-2, 2:-2]
    code = np.where(code > 127, 255, 0).astype(np.uint8)
    pad = np.pad(code, quiet, constant_values=255)
    return cv2.resize(pad, None, fx=modules_px, fy=modules_px, interpolation=cv2.INTER_NEAREST), code.shape[0]


def render(tex, modules, quiet, fwd, left, yaw_off, rng, noise=3.0, blur=0.8):
    """Plate (normal toward the camera's start heading) `fwd` m ahead, `left` m left."""
    side = QR * tex.shape[0] / (tex.shape[0] - 2 * quiet * tex.shape[0] / (modules + 2 * quiet))
    plane = QR * (modules + 2 * quiet) / modules
    cam_yaw = math.pi + yaw_off
    fwd_v = np.array([math.cos(cam_yaw), math.sin(cam_yaw)])
    left_v = np.array([-math.sin(cam_yaw), math.cos(cam_yaw)])
    plate_xy = fwd * fwd_v + left * left_v                         # camera at the origin
    f = np.array([math.cos(PITCH) * math.cos(cam_yaw), math.cos(PITCH) * math.sin(cam_yaw), math.sin(PITCH)])
    r = np.array([math.sin(cam_yaw), -math.cos(cam_yaw), 0.0])
    d = np.cross(f, r)
    C = np.array([0.0, 0.0, CAM_Z])
    corners = [(-plane / 2, plane / 2), (plane / 2, plane / 2), (plane / 2, -plane / 2), (-plane / 2, -plane / 2)]
    dst = []
    for (u, v) in corners:        # plate faces +x (world), viewer at +x: right = +y, up = +z
        p = np.array([plate_xy[0], plate_xy[1] + u, PLATE_Z + v]) - C
        zc = p @ f
        dst.append([FX * (p @ r) / zc + W / 2, FX * (p @ d) / zc + H / 2])
    th, tw = tex.shape[:2]
    M = cv2.getPerspectiveTransform(np.float32([[0, 0], [tw, 0], [tw, th], [0, th]]), np.float32(dst))
    img = np.full((H, W), 120, np.uint8)
    warp = cv2.warpPerspective(tex, M, (W, H), flags=cv2.INTER_AREA, borderValue=120)
    mask = cv2.warpPerspective(np.full_like(tex, 255), M, (W, H))
    img = np.where(mask > 128, warp, img)
    img = cv2.GaussianBlur(img, (0, 0), blur)
    img = np.clip(img.astype(float) + rng.normal(0, noise, img.shape), 0, 255).astype(np.uint8)
    # horizontal distance camera -> plate along the camera heading
    true_fwd = (plate_xy @ fwd_v)
    true_left = (plate_xy @ left_v)
    return cv2.cvtColor(img, cv2.COLOR_GRAY2BGR), true_fwd, true_left


def main():
    rng = np.random.default_rng(2)
    tex, modules = make_tex('RACKA_4X6M')
    fails, worst_f, worst_l, n = 0, 0.0, 0.0, 0
    print(f'{"fwd":>5} {"left":>6} {"yaw":>5} | {"est fwd":>8} {"est left":>8} {"err_f":>6} {"err_l":>6}')
    for fwd in (0.25, 0.30, 0.35, 0.45, 0.55, 0.65):
        for left in (-0.10, 0.0, 0.10):
            for yaw in (-0.15, 0.0, 0.15):
                img, tf, tl = render(tex, modules, 4, fwd, left, yaw, rng)
                text, corners = decode_qr_ex(img, 640)
                if text != 'RACKA_4X6M':
                    print(f'{fwd:5.2f} {left:6.2f} {yaw:5.2f} | NOT DECODED')
                    if fwd <= 0.45:
                        fails += 1
                    continue
                p = qr_pose(corners, QR, FX, FX, W / 2, H / 2, PITCH)
                ef, el = p['fwd'] - tf, p['left'] - tl
                n += 1
                if fwd <= 0.45:
                    worst_f, worst_l = max(worst_f, abs(ef)), max(worst_l, abs(el))
                print(f'{fwd:5.2f} {left:6.2f} {yaw:5.2f} | {p["fwd"]:8.3f} {p["left"]:8.3f} {ef:6.3f} {el:6.3f}')
    # the old API still works
    assert decode_qr(render(tex, modules, 4, 0.35, 0.0, 0.0, rng)[0]) == 'RACKA_4X6M'
    # a larger frame is downscaled but the corners come back in ORIGINAL pixels
    big = cv2.resize(render(tex, modules, 4, 0.35, 0.0, 0.0, rng)[0], None, fx=2.0, fy=2.0)
    text, corners = decode_qr_ex(big, 640)
    assert text == 'RACKA_4X6M' and corners is not None
    assert 0 <= corners[:, 0].max() <= 1280 and corners[:, 0].min() > 200, corners
    print(f'\ndecoded {n} frames; worst error within 0.45 m: fwd {worst_f * 100:.1f} cm, left {worst_l * 100:.1f} cm; '
          f'decode failures within 0.45 m: {fails}')
    assert fails == 0 and worst_f < 0.03 and worst_l < 0.02
    print('QR geometry test PASSED')


if __name__ == '__main__':
    main()
