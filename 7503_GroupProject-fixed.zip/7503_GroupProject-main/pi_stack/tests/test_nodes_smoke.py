"""Smoke test of the three small ROS nodes with fake ROS: qr_node, odom_to_tf, lift_bridge.

    cd pi_stack && python3 tests/test_nodes_smoke.py

Runs the real callbacks end to end (no ROS needed), so typos / wrong field names / bad
message handling show up here and not on the Pi.
"""
import json
import math
import os
import sys
import types

import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
PI = os.path.dirname(HERE)
sys.path.insert(0, HERE)
import sim_harness as H  # noqa: E402
import test_qr_geometry as G  # noqa: E402


def build_world():
    w = H.World({'A': (1.0, 1.0)}, {}, 0)
    H.install_stubs(w)

    def mod(name, **attrs):
        m = types.ModuleType(name)
        m.__dict__.update(attrs)
        sys.modules[name] = m

    sys.modules['rclpy.node'].Node  # already stubbed by install_stubs
    mod('rclpy.qos', qos_profile_sensor_data=10)
    mod('nav_msgs')
    mod('nav_msgs.msg', Odometry=H.msg_class())
    mod('sensor_msgs')
    mod('sensor_msgs.msg', Image=H.msg_class(), CameraInfo=H.msg_class())
    mod('geometry_msgs.msg', PoseStamped=H.msg_class(), PoseWithCovarianceStamped=H.msg_class(),
        Twist=H.msg_class(), TransformStamped=H.msg_class())
    sent = []
    mod('tf2_ros', Buffer=object, TransformListener=object,
        TransformBroadcaster=lambda node: types.SimpleNamespace(sendTransform=sent.append))
    w.sent_tf = sent
    return w


def load(path_dir, name):
    sys.path.insert(0, path_dir)
    for n in [n for n in sys.modules if n == name.split('.')[0] or n.startswith(name.split('.')[0] + '.')]:
        del sys.modules[n]
    import importlib
    return importlib.import_module(name)


def published(w, topic):
    return [m for _, m in w.published.get(topic, [])]


def test_lift_bridge():
    w = build_world()
    import importlib.util
    spec = importlib.util.spec_from_file_location(
        'lift_bridge', os.path.join(PI, 'src/robot_bringup/scripts/lift_bridge.py'))
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    node = mod.LiftBridge()
    node._on_cmd(types.SimpleNamespace(data='up'))
    node._on_cmd(types.SimpleNamespace(data='down'))
    node._on_cmd(types.SimpleNamespace(data='sideways'))
    s1 = [m.data for m in published(w, 'servo_s1')]
    assert s1 == [90, 90, 90, 50, 50, 50], s1
    assert not published(w, 'servo_s2'), 'servo_s2 must stay untouched by default'
    print('lift_bridge: up -> servo_s1 90, down -> 50, unknown word ignored, S2 untouched  OK')


def test_odom_to_tf():
    w = build_world()
    import importlib.util
    spec = importlib.util.spec_from_file_location(
        'odom_to_tf', os.path.join(PI, 'src/robot_bringup/scripts/odom_to_tf.py'))
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    w.t = 100.0
    node = mod.OdomToTf()
    msg = H.msg_class()()
    msg.header.stamp.sec, msg.header.stamp.nanosec = 7, 0           # garbage firmware stamp
    msg.header.frame_id, msg.child_frame_id = 'odom_frame', 'base_footprint'
    msg.pose.pose.position.x, msg.pose.pose.position.y = 1.5, -0.25
    msg.pose.pose.orientation.z, msg.pose.pose.orientation.w = math.sin(0.3), math.cos(0.3)
    msg.pose.covariance = [0.0] * 36
    msg.twist.covariance = [0.0] * 36
    node._on_odom(msg)
    tf = w.sent_tf[-1]
    assert (tf.header.frame_id, tf.child_frame_id) == ('odom', 'base_link')
    assert abs(tf.header.stamp.sec - 100) <= 1, tf.header.stamp.sec     # Pi clock, not the garbage 7
    assert tf.transform.translation.x == 1.5
    out = published(w, '/odom')[-1]
    assert (out.header.frame_id, out.child_frame_id) == ('odom', 'base_link')
    assert out.pose.covariance[0] > 0 and out.twist.covariance[35] > 0
    print('odom_to_tf: /odom_raw -> /odom + TF odom->base_link, Pi-clock stamp, covariance filled  OK')


def test_qr_node():
    w = build_world()
    w.t = 5.0
    # cv_bridge stub: hand back the BGR frame that the "camera" captured
    frame = {}
    sys.modules['cv_bridge'] = types.SimpleNamespace(
        CvBridge=lambda: types.SimpleNamespace(imgmsg_to_cv2=lambda msg, desired_encoding='bgr8': frame['img']))
    mod = load(os.path.join(PI, 'src/qr_scanner'), 'qr_scanner.qr_node')
    node = mod.QrScannerNode('/camera/image_raw', '/qr_detected', rate=0, qr_side=G.QR,
                             pitch_up=G.PITCH, hfov=G.HFOV)
    rng = np.random.default_rng(4)
    tex, modules = G.make_tex('RACKB_4X6M')
    img, true_fwd, true_left = G.render(tex, modules, 4, 0.35, 0.05, 0.05, rng)
    frame['img'] = img
    msg = H.msg_class()()
    msg.header.stamp.sec, msg.header.stamp.nanosec = 4, 500
    node._on_image(msg)
    text = [m.data for m in published(w, '/qr_detected')]
    det = [json.loads(m.data) for m in published(w, '/qr_detection')]
    assert text == ['RACKB_4X6M'], text
    assert len(det) == 1 and det[0]['text'] == 'RACKB_4X6M'
    assert (det[0]['sec'], det[0]['nanosec']) == (4, 500)
    assert abs(det[0]['fwd'] - true_fwd) < 0.02 and abs(det[0]['left'] - true_left) < 0.02, (det[0], true_fwd, true_left)
    # fast mode toggles the decode interval
    node._on_fast(types.SimpleNamespace(data=True))
    assert node._min_interval_ns == int(1e9 / 8.0)
    node._on_fast(types.SimpleNamespace(data=False))
    assert node._min_interval_ns == 0       # rate=0 means "every frame" in normal mode
    # CameraInfo overrides the focal length estimate
    info = H.msg_class()()
    info.k = [500.0, 0, 320.0, 0, 510.0, 240.0, 0, 0, 1.0]
    node._on_info(info)
    assert node._intrinsics == (500.0, 510.0, 320.0, 240.0)
    print(f'qr_node: decoded {text[0]} at fwd {det[0]["fwd"]:.3f} (true {true_fwd:.3f}), '
          f'left {det[0]["left"]:.3f} (true {true_left:.3f}); fast mode + CameraInfo handled  OK')


def main():
    test_lift_bridge()
    test_odom_to_tf()
    test_qr_node()
    print('Node smoke test PASSED')


if __name__ == '__main__':
    main()
