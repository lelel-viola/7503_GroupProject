"""Run the REAL game_manager_node.py without ROS, in a small kinematic world.

Faked   : rclpy (clock, timers, publishers, subscriptions, action client), TF, Nav2
          (a goal "teleports" the robot after a travel time, with Nav2-sized error),
          the QR camera (visibility cone, range, noise) and the lift / grab.
Real    : every line of game_manager_node.py and motion.py.

World frame = the map frame of the course drawing (x from the destination towards START,
y up).  Racks are portal frames 0.14 (x) x 0.35 (y) m with the QR plate on the +x face.
Robot chassis is assumed 0.26 m wide, rack legs leave 0.31 m between their inner faces.
"""
import copy
import importlib.util
import json
import math
import os
import sys
import types

import numpy as np
import yaml

HERE = os.path.dirname(os.path.abspath(__file__))
PI_STACK = os.path.dirname(HERE)
GM_SRC = os.path.join(PI_STACK, 'src', 'game_manager')

FIELD = (3.02, 2.00)
DEST = (0.0, 0.8, 0.3, 1.7)
RACK_DX, RACK_DY = 0.14, 0.35
LEG = 0.02
LEG_X, LEG_Y = RACK_DX / 2 - LEG / 2, RACK_DY / 2 - LEG / 2      # leg centres
PLATE_Z, CAM_Z, CAM_FWD, PITCH = 0.2325, 0.17, 0.12, 0.10
HFOV, QR_SIDE = 1.0, 0.05
FX = 320.0 / math.tan(HFOV / 2)
CHASSIS_HX, CHASSIS_HY = 0.15, 0.13
FOOT = 0.16                                                      # Nav2 planning footprint
START_PLATE = (2.30, 1.00)     # START post, QR faces +x
END_PLATE = (0.10, 1.00)       # END frame on the destination wall, QR faces +x
ROBOT_START = (2.72, 1.00, math.pi)


def wrap(a):
    return math.atan2(math.sin(a), math.cos(a))


# ----------------------------------------------------------------------------- fake ROS
class AutoNS:
    def __init__(self, **kw):
        self.__dict__.update(kw)

    def __getattr__(self, name):
        if name.startswith('__'):
            raise AttributeError(name)
        v = AutoNS()
        self.__dict__[name] = v
        return v


def msg_class(**defaults):
    class Msg(AutoNS):
        def __init__(self, **kw):
            super().__init__(**copy.deepcopy(defaults))
            self.__dict__.update(kw)
    return Msg


class Duration:
    def __init__(self, seconds=0.0, nanoseconds=0):
        self.nanoseconds = int(seconds * 1e9) + int(nanoseconds)


class Time:
    def __init__(self, seconds=0, nanoseconds=0, clock_type=None):
        self.nanoseconds = int(seconds * 1e9) + int(nanoseconds)

    def __add__(self, d):
        return Time(nanoseconds=self.nanoseconds + d.nanoseconds)

    def __sub__(self, o):
        return Duration(nanoseconds=self.nanoseconds - o.nanoseconds)

    def __ge__(self, o):
        return self.nanoseconds >= o.nanoseconds

    def __lt__(self, o):
        return self.nanoseconds < o.nanoseconds

    def to_msg(self):
        return AutoNS(sec=self.nanoseconds // 10 ** 9, nanosec=self.nanoseconds % 10 ** 9)


class Future:
    def __init__(self):
        self._cbs, self._result, self.done = [], None, False

    def add_done_callback(self, cb):
        if self.done:
            cb(self)
        else:
            self._cbs.append(cb)

    def set_result(self, r):
        self._result, self.done = r, True
        for cb in self._cbs:
            cb(self)

    def result(self):
        return self._result


class Logger:
    def __init__(self, world):
        self.w = world

    def _log(self, level, msg):
        self.w.logs.append((self.w.t, level, msg))
        if self.w.verbose or level in ('WARN', 'ERROR'):
            print(f'    [{self.w.t:6.1f}s {level}] {msg}')

    def info(self, m, **k):
        self._log('INFO', m)

    def debug(self, m, **k):
        pass

    def warn(self, m, **k):
        self._log('WARN', m)

    warning = warn

    def error(self, m, **k):
        self._log('ERROR', m)


class Timer:
    def __init__(self, period, cb):
        self.period, self.cb, self.next = period, cb, 0.0


class Publisher:
    def __init__(self, world, topic):
        self.w, self.topic = world, topic

    def publish(self, msg):
        self.w.on_publish(self.topic, msg)


def install_stubs(world):
    def mod(name, **attrs):
        m = types.ModuleType(name)
        m.__dict__.update(attrs)
        sys.modules[name] = m
        return m

    class FakeNode:
        def __init__(self, name):
            world.params_declared = getattr(world, 'params_declared', {})
            self._params = {}
            self._logger = Logger(world)

        def declare_parameter(self, name, default=None):
            p = types.SimpleNamespace(value=world.params.get(name, default))
            self._params[name] = p
            return p

        def get_parameter(self, name):
            return self._params[name]

        def create_publisher(self, typ, topic, qos=10):
            return Publisher(world, topic)

        def create_subscription(self, typ, topic, cb, qos=10):
            world.subs.setdefault(topic, []).append(cb)

        def create_timer(self, period, cb):
            world.timers.append(Timer(period, cb))

        def get_clock(self):
            return world.clock

        def get_logger(self):
            return self._logger

        def destroy_node(self):
            pass

    class ActionClient:
        def __init__(self, node, typ, name):
            world.nav_client = self

        def wait_for_server(self, timeout_sec=0):
            return True

        def send_goal_async(self, goal):
            fut = Future()
            world.on_nav_goal(goal, fut)
            return fut

    class Buffer:
        def lookup_transform(self, target, source, t):
            if not world.tf_ok:
                raise RuntimeError('no tf')
            x, y, yaw = world.robot.x, world.robot.y, world.robot.yaw
            return AutoNS(transform=AutoNS(
                translation=AutoNS(x=x, y=y, z=0.0),
                rotation=AutoNS(x=0.0, y=0.0, z=math.sin(yaw / 2), w=math.cos(yaw / 2))))

    mod('rclpy', ok=lambda: True, init=lambda args=None: None, shutdown=lambda: None,
        spin=lambda n: None)
    mod('rclpy.action', ActionClient=ActionClient)
    mod('rclpy.clock', ClockType=types.SimpleNamespace(ROS_TIME=1, SYSTEM_TIME=0))
    mod('rclpy.duration', Duration=Duration)
    mod('rclpy.executors', ExternalShutdownException=type('ExternalShutdownException', (Exception,), {}))
    mod('rclpy.node', Node=FakeNode)
    mod('rclpy.time', Time=Time)
    mod('action_msgs', )
    mod('action_msgs.msg', GoalStatus=types.SimpleNamespace(STATUS_SUCCEEDED=4, STATUS_ABORTED=6,
                                                           STATUS_CANCELED=5))
    PWCS = msg_class()
    mod('geometry_msgs', )
    mod('geometry_msgs.msg', PoseStamped=msg_class(), PoseWithCovarianceStamped=type(
        'PWCS', (AutoNS,), {'__init__': lambda self: (AutoNS.__init__(self),
                                                     setattr(self, 'pose', AutoNS(covariance=[0.0] * 36)))[0]}),
        Twist=msg_class())
    mod('std_msgs', )
    mod('std_msgs.msg', String=msg_class(data=''), Int32=msg_class(data=0), Bool=msg_class(data=False))
    mod('nav2_msgs', )
    mod('nav2_msgs.action', NavigateToPose=types.SimpleNamespace(Goal=msg_class()))
    mod('tf2_ros', Buffer=Buffer, TransformListener=lambda buf, node: None)


# ----------------------------------------------------------------------------- the world
class Robot:
    def __init__(self):
        self.x, self.y, self.yaw = ROBOT_START
        self.v = self.w = 0.0


class World:
    def __init__(self, true_racks, params, seed=0, qr_geometry=True, verbose=False,
                 chassis_hy=CHASSIS_HY, nav_fail_first=False):
        self.rng = np.random.default_rng(seed)
        self.params = params
        self.verbose = verbose
        self.t = 0.0
        self.clock = types.SimpleNamespace(now=lambda: Time(nanoseconds=int(self.t * 1e9)))
        self.logs, self.subs, self.timers = [], {}, []
        self.published = {}
        self.robot = Robot()
        self.tf_ok = True
        self.cmd = (0.0, 0.0)
        self.racks = {k: {'x': v[0], 'y': v[1], 'yaw': 0.0} for k, v in true_racks.items()}
        self.attached = None
        self.rel_yaw = 0.0
        self.lifted = False
        self.fast = False
        self.qr_geometry = qr_geometry
        self.chassis_hy = chassis_hy
        self.collisions = {'wall': 0, 'rack': 0}
        self._in_col = {'wall': False, 'rack': False}
        self.pending_nav = None
        self.nav_fail_first = nav_fail_first
        self.last_qr_pub = {}
        self.next_qr_t = 0.0
        self.missed_grabs = 0
        self.scanned = []
        self.state = None

    # -------------------------------------------------------------- messaging
    def on_publish(self, topic, msg):
        self.published.setdefault(topic, []).append((self.t, msg))
        if topic == '/cmd_vel':
            self.cmd = (msg.linear.x, msg.angular.z)
        elif topic == '/qr_fast_mode':
            self.fast = bool(msg.data)
        elif topic == '/lift_cmd':
            self.on_lift(msg.data)
        elif topic == '/game_state':
            self.state = msg.data
        for cb in self.subs.get(topic, []):
            cb(msg)

    def deliver(self, topic, msg):
        for cb in self.subs.get(topic, []):
            cb(msg)

    # -------------------------------------------------------------- geometry helpers
    def rack_legs(self, k):
        r = self.racks[k]
        c, s = math.cos(r['yaw']), math.sin(r['yaw'])
        return [(r['x'] + c * sx * LEG_X - s * sy * LEG_Y, r['y'] + s * sx * LEG_X + c * sy * LEG_Y)
                for sx in (1, -1) for sy in (1, -1)]

    @staticmethod
    def rect_pts(x, y, yaw, hx, hy, n=14):
        pts = []
        for t in np.linspace(-1, 1, n):
            pts += [(hx, t * hy), (-hx, t * hy), (t * hx, hy), (t * hx, -hy)]
        c, s = math.cos(yaw), math.sin(yaw)
        return [(x + c * px - s * py, y + s * px + c * py) for px, py in pts]

    def planning_clearance(self, x, y, yaw):
        best = 1e9
        for px, py in self.rect_pts(x, y, yaw, FOOT, FOOT, 30):
            best = min(best, px, FIELD[0] - px, py, FIELD[1] - py)
            for k, r in self.racks.items():
                if k == self.attached and self.lifted:
                    continue
                c, s = math.cos(r['yaw']), math.sin(r['yaw'])
                dx, dy = px - r['x'], py - r['y']
                lx, ly = c * dx + s * dy, -s * dx + c * dy
                ox, oy = max(abs(lx) - RACK_DX / 2, 0), max(abs(ly) - RACK_DY / 2, 0)
                if ox == 0 and oy == 0:
                    best = min(best, -0.01)
                else:
                    best = min(best, math.hypot(ox, oy))
        return best

    # -------------------------------------------------------------- lift / rack
    def on_lift(self, word):
        rb = self.robot
        if word == 'up' and self.attached is None:
            for k, r in self.racks.items():
                c, s = math.cos(r['yaw']), math.sin(r['yaw'])
                dx, dy = rb.x - r['x'], rb.y - r['y']
                along, lat = dx * c + dy * s, -dx * s + dy * c
                if abs(along) < 0.07 and abs(lat) < 0.05:
                    self.attached, self.rel_yaw, self.lifted = k, wrap(r['yaw'] - rb.yaw), True
                    return
            self.missed_grabs += 1
        elif word == 'down':
            self.lifted = False
            self.attached = None

    def sync_rack(self):
        if self.attached and self.lifted:
            r, rb = self.racks[self.attached], self.robot
            r['x'], r['y'], r['yaw'] = rb.x, rb.y, wrap(rb.yaw + self.rel_yaw)

    # -------------------------------------------------------------- Nav2
    def on_nav_goal(self, goal, fut):
        p = goal.pose.pose
        x, y = p.position.x, p.position.y
        yaw = 2 * math.atan2(p.orientation.z, p.orientation.w)
        rb = self.robot
        ok = self.planning_clearance(x, y, wrap(yaw)) >= 0.0
        if self.nav_fail_first:
            self.nav_fail_first = False
            ok = False
        dist = math.hypot(x - rb.x, y - rb.y)
        rot = abs(wrap(math.atan2(y - rb.y, x - rb.x) - rb.yaw)) + abs(wrap(yaw - math.atan2(y - rb.y, x - rb.x)))
        eta = dist / 0.22 + rot / 0.8 + 1.5
        handle = AutoNS(accepted=True)
        res_fut = Future()
        handle.get_result_async = lambda: res_fut
        handle.cancel_goal_async = lambda: setattr(self, 'pending_nav', None)
        self.pending_nav = {'t_end': self.t + (eta if ok else 4.0), 'goal': (x, y, wrap(yaw)),
                            'ok': ok, 'fut': res_fut}
        fut.set_result(handle)

    # -------------------------------------------------------------- QR camera
    def visible_plates(self):
        rb = self.robot
        cx = rb.x + CAM_FWD * math.cos(rb.yaw)
        cy = rb.y + CAM_FWD * math.sin(rb.yaw)
        plates = [('START', START_PLATE[0] + 0.03, START_PLATE[1], 0.15, 0.0),
                  ('END', END_PLATE[0] + 0.03, END_PLATE[1], 0.15, 0.0)]
        for k, r in self.racks.items():
            d = RACK_DX / 2 + 0.004
            plates.append((f'RACK{k}_4X6M', r['x'] + d * math.cos(r['yaw']),
                           r['y'] + d * math.sin(r['yaw']), PLATE_Z, r['yaw']))
        out = []
        for text, px, py, pz, nyaw in plates:
            dx, dy = px - cx, py - cy
            fwd_h = dx * math.cos(rb.yaw) + dy * math.sin(rb.yaw)
            left = -dx * math.sin(rb.yaw) + dy * math.cos(rb.yaw)
            if fwd_h < 0.12 or math.hypot(dx, dy) > 0.9:
                continue
            if abs(math.atan2(left, fwd_h)) > 0.40:
                continue
            elev = math.atan2(pz - CAM_Z, fwd_h) - PITCH
            if abs(elev) > 0.30:
                continue
            los = math.atan2(cy - py, cx - px)
            if abs(wrap(los - nyaw)) > math.radians(55):
                continue
            z = fwd_h * math.cos(PITCH) + (pz - CAM_Z) * math.sin(PITCH)
            if FX * QR_SIDE / max(z, 1e-3) < 30:
                continue
            out.append((text, fwd_h, left, pz - CAM_Z))
        return out

    def camera_step(self):
        if self.t < self.next_qr_t:
            return
        self.next_qr_t = self.t + (1 / 8.0 if self.fast else 1 / 3.0)
        for text, fwd, left, up in self.visible_plates():
            fwd_n = fwd + self.rng.normal(0, 0.006 + 0.01 * fwd)
            left_n = left + self.rng.normal(0, 0.004)
            if self.qr_geometry:
                det = {'text': text, 'fwd': fwd_n, 'left': left_n, 'up': up,
                       'bearing': math.atan2(left_n, fwd_n), 'size_px': 50.0,
                       'sec': int(self.t), 'nanosec': int((self.t % 1) * 1e9)}
                self.on_publish('/qr_detection', types.SimpleNamespace(data=json.dumps(det)))
            if text != self.last_qr_pub.get('text') or self.t - self.last_qr_pub.get('t', -9) > 2.0:
                self.last_qr_pub = {'text': text, 't': self.t}
                self.scanned.append((round(self.t, 1), text))
                self.on_publish('/qr_detected', types.SimpleNamespace(data=text))

    # -------------------------------------------------------------- physics
    def check_collisions(self):
        rb = self.robot
        pts = self.rect_pts(rb.x, rb.y, rb.yaw, CHASSIS_HX, self.chassis_hy)
        wall = any(not (0 <= px <= FIELD[0] and 0 <= py <= FIELD[1]) for px, py in pts)
        rack_hit = False
        for k in self.racks:
            if k == self.attached and self.lifted:
                continue
            for lx, ly in self.rack_legs(k):
                if any(abs(px - lx) < LEG / 2 and abs(py - ly) < LEG / 2 for px, py in pts):
                    rack_hit = True
        if self.attached and self.lifted:                      # carried rack vs walls
            r = self.racks[self.attached]
            rp = self.rect_pts(r['x'], r['y'], r['yaw'], RACK_DX / 2, RACK_DY / 2)
            wall = wall or any(not (0 <= px <= FIELD[0] and 0 <= py <= FIELD[1]) for px, py in rp)
        for key, hit in (('wall', wall), ('rack', rack_hit)):
            if hit and not self._in_col[key]:
                self.collisions[key] += 1
                if self.verbose:
                    print(f'    [{self.t:6.1f}s COLLISION] {key}')
            self._in_col[key] = hit

    def step(self, dt):
        rb = self.robot
        # chassis follows the last /cmd_vel with a first-order lag
        a = dt / (0.2 + dt)
        rb.v += a * (self.cmd[0] - rb.v)
        rb.w += a * (self.cmd[1] - rb.w)
        if self.pending_nav is None:
            rb.x += rb.v * math.cos(rb.yaw) * dt
            rb.y += rb.v * math.sin(rb.yaw) * dt
            rb.yaw = wrap(rb.yaw + rb.w * dt)
        self.t += dt
        pn = self.pending_nav
        if pn is not None and self.t >= pn['t_end']:
            self.pending_nav = None
            if pn['ok']:
                gx, gy, gyaw = pn['goal']
                rb.x, rb.y = gx + self.rng.normal(0, 0.03), gy + self.rng.normal(0, 0.03)
                rb.yaw = wrap(gyaw + self.rng.normal(0, 0.05))
                rb.v = rb.w = 0.0
                pn['fut'].set_result(AutoNS(status=4))
            else:
                pn['fut'].set_result(AutoNS(status=6))
        self.sync_rack()
        self.check_collisions()
        self.camera_step()
        for tm in self.timers:
            while self.t >= tm.next:
                tm.next += tm.period
                tm.cb()

    # -------------------------------------------------------------- results
    def racks_in_zone(self):
        out = []
        for k, r in self.racks.items():
            ok = (DEST[0] <= r['x'] - RACK_DX / 2 and r['x'] + RACK_DX / 2 <= DEST[1] and
                  DEST[2] <= r['y'] - RACK_DY / 2 and r['y'] + RACK_DY / 2 <= DEST[3])
            if ok and not (self.attached == k and self.lifted):
                out.append(k)
        return sorted(out)


# ----------------------------------------------------------------------------- running a game
def load_params(path):
    with open(path) as f:
        return yaml.safe_load(f)['game_manager']['ros__parameters']


def load_node_module(path, package_dir=None):
    """Import game_manager_node.py (new one as part of its package, old one standalone)."""
    if package_dir:
        sys.path.insert(0, package_dir)
        for name in [n for n in sys.modules if n == 'game_manager' or n.startswith('game_manager.')]:
            del sys.modules[name]
        return importlib.import_module('game_manager.game_manager_node')
    spec = importlib.util.spec_from_file_location('old_game_manager_node', path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def run_game(node_module_loader, params, true_racks, seed=0, qr_geometry=True, verbose=False,
             max_time=260.0, chassis_hy=CHASSIS_HY, nav_fail_first=False, start_qr=True):
    world = World(true_racks, params, seed, qr_geometry, verbose, chassis_hy, nav_fail_first)
    install_stubs(world)
    module = node_module_loader()
    gm = module.GameManager()
    world.gm = gm
    dt = 0.02
    started = False
    while world.t < max_time:
        if start_qr and not started and world.t > 1.0:
            started = True
        world.step(dt)
        if getattr(gm, '_state', None) == 'DONE':
            break
    return world, gm
