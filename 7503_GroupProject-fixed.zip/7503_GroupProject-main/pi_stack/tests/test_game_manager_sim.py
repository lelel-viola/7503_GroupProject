"""Scenario tests: the patched game_manager (real code) on the fake field.

    cd pi_stack && python3 tests/test_game_manager_sim.py [-v]

No ROS needed.  See sim_harness.py for what is faked.
"""
import math
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import sim_harness as H  # noqa: E402

PARAMS = os.path.join(H.GM_SRC, 'config', 'game_params.yaml')
LOADER = lambda: H.load_node_module(None, H.GM_SRC)  # noqa: E731

# Estimated TRUE rack centres (see docs/FIX_NOTES.md) -- what the real field looks like.
TRUE = {'A': (1.130, 0.525), 'B': (1.830, 1.385), 'C': (1.320, 1.695), 'D': (1.920, 0.385)}

# The ORIGINAL repo's configuration (150x140 racks, approached from the side).
OLD_CENTRES = {'A': (1.275, 1.580), 'B': (1.825, 0.510), 'C': (1.925, 1.720), 'D': (1.325, 0.200)}
OLD_APPROACH = {'A': (1.275, 1.230, math.pi / 2), 'B': (1.825, 0.860, -math.pi / 2),
                'C': (1.925, 1.370, math.pi / 2), 'D': (1.325, 0.550, -math.pi / 2)}


def with_params(**over):
    p = H.load_params(PARAMS)
    p.update(over)
    return p


def shifted(truth, dx, dy):
    """Configuration that is wrong by (dx, dy) (alternating sign per rack)."""
    out = {}
    for i, (k, (x, y)) in enumerate(truth.items()):
        s = 1 if i % 2 == 0 else -1
        out[k] = (x + s * dx, y - s * dy)
    return out


def apply_centres(p, centres):
    """Put rack centres (and the approach poses derived from them) into the params."""
    for k, (cx, cy) in centres.items():
        low = k.lower()
        p[f'rack_{low}_cx'], p[f'rack_{low}_cy'] = cx, cy
        # the approach pose follows the same recipe as tools/make_game_params.py
        old = (p[f'rack_{low}_x'], p[f'rack_{low}_y'])
        base = H.load_params(PARAMS)
        p[f'rack_{low}_x'] = base[f'rack_{low}_x'] + (cx - base[f'rack_{low}_cx'])
        p[f'rack_{low}_y'] = base[f'rack_{low}_y'] + (cy - base[f'rack_{low}_cy'])
    return p


def report(title, world, gm, expect_n=None, expect_collisions=0):
    inside = world.racks_in_zone()
    cols = sum(world.collisions.values())
    ok = True
    if expect_n is not None:
        ok &= len(inside) >= expect_n
    ok &= cols <= expect_collisions
    print(f'--> {title}: racks in destination zone {inside}, collisions {world.collisions}, '
          f'missed grabs {world.missed_grabs}, game time {world.t:5.1f}s  '
          f'{"PASS" if ok else "FAIL"}')
    return ok, inside


def main():
    verbose = '-v' in sys.argv
    results = []

    print('\n=== 1) corrected config, true positions = config, QR geometry available')
    w, gm = H.run_game(LOADER, with_params(), TRUE, seed=1, verbose=verbose)
    results.append(report('nominal', w, gm, expect_n=4)[0])
    order = [t for _, t in w.scanned if t.startswith('RACK')]
    seen = []
    for t in order:
        if t[4] not in seen:
            seen.append(t[4])
    print('    rack QR first-read order:', seen)

    print('\n=== 2) config wrong by ~8 cm in x and y: the QR must pull the robot in line')
    p = apply_centres(with_params(), shifted(TRUE, 0.08, 0.08))
    w, gm = H.run_game(LOADER, p, TRUE, seed=2, verbose=verbose)
    results.append(report('config off by 8 cm', w, gm, expect_n=4)[0])

    print('\n=== 3) no QR geometry (only the text): docking on the nominal centres')
    w, gm = H.run_game(LOADER, with_params(), TRUE, seed=3, qr_geometry=False, verbose=verbose)
    results.append(report('nominal docking', w, gm, expect_n=4)[0])

    print('\n=== 4) tighter chassis: only 1.5 cm clearance each side between the rack legs')
    w, gm = H.run_game(LOADER, with_params(), TRUE, seed=4, chassis_hy=0.14, verbose=verbose)
    results.append(report('1.5 cm clearance', w, gm, expect_n=4)[0])

    print('\n=== 5) Nav2 rejects the first goal (retry logic)')
    w, gm = H.run_game(LOADER, with_params(), TRUE, seed=5, nav_fail_first=True, verbose=verbose)
    results.append(report('nav fail once', w, gm, expect_n=4)[0])

    print('\n=== 6) the ORIGINAL configuration (150x140 racks, side approach, C/D swapped),')
    print('       docking off = the original behaviour, on the field as measured here')
    p = with_params(use_docking=False)
    for k, (x, y, yaw) in OLD_APPROACH.items():
        low = k.lower()
        p[f'rack_{low}_x'], p[f'rack_{low}_y'], p[f'rack_{low}_yaw'] = x, y, yaw
    p['destination_points'] = '0.40,0.45,3.1416; 0.40,0.85,3.1416; 0.40,1.25,3.1416; 0.40,1.62,3.1416'
    w, gm = H.run_game(LOADER, p, TRUE, seed=6, verbose=verbose)
    inside, cols = w.racks_in_zone(), sum(w.collisions.values())
    print(f'--> original config: racks in destination zone {inside}, collisions {w.collisions}, '
          f'scanned QR codes {sorted({t for _, t in w.scanned if t.startswith("RACK")})}')
    results.append(len(inside) == 0)          # expected to FAIL to deliver - that is the point

    print('\n=== 7) corrected positions but C and D hints swapped: must skip, never lift the wrong rack')
    swapped = dict(TRUE)
    swapped['C'], swapped['D'] = TRUE['D'], TRUE['C']
    p = apply_centres(with_params(), swapped)
    w, gm = H.run_game(LOADER, p, TRUE, seed=7, verbose=verbose)
    ok, inside = report('swapped C/D', w, gm, expect_n=2)
    results.append(ok and set(inside) >= {'A', 'B'})

    print('\nSUMMARY: %d/%d scenarios as expected' % (sum(results), len(results)))
    print('Game manager simulation test', 'PASSED' if all(results) else 'FINISHED WITH ISSUES')
    return 0 if all(results) else 1


if __name__ == '__main__':
    sys.exit(main())
